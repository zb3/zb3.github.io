<?php
if (!file_exists('zb3shell.vfs')) die('Call makevfs first!');
$f = file_get_contents('serverside.php');
$f2 = substr(file_get_contents('zb3shell.vfs'), 6);
file_put_contents('zb3shell.php', str_replace('include(\'zb3shell.vfs\');', $f2, $f));