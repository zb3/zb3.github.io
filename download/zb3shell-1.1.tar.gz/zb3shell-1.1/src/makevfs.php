<?php
$tovfs = array('enabled.gif', 'styles.css', 'zb3shell.js', 'serverside', 'serverside.c', 'keyboard.png', 'keyboard.html');
$newcont = "<?php\n";

foreach($tovfs as $file)
{
 $fcont = file_get_contents($file);
 $fcont = base64_encode($fcont);
 $newcont .= "\n".'$vfs[\''.$file.'\'] = \''.$fcont.'\';';
}
file_put_contents('zb3shell.vfs', $newcont);