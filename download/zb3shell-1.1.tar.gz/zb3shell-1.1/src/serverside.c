#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>
#include <stdint.h>
#include <signal.h>

char fname0[4096], fname1[4096], fname2[4096], fname3[4096];
void echo(const char *str)
{
 fprintf(stdout, "%s", str); fflush(stdout);
}
void echon(int str)
{
 fprintf(stdout, "%d", str); fflush(stdout);
}

int ourpid = 0, cend[2];
int ptyfd, f0, f1, f2, f3, x, y; struct winsize w;
int ok = 1;
pthread_t t0, t1, t2, t3;

void cwrite(int fd, void *buf, size_t size)
{
 size_t written = 0; int tmp = 0;
 while(ok && (written<size))
 {
  tmp = write(fd, buf+written, size-written);
  if (tmp>0) written += tmp;
 } 
}
void *sizewatch()
{
 char buf[48]; int tmp = 0; int tmp2 = 0;
 while (ok)
 {
  while(ok && (tmp<48))
  {
   tmp2 = read(f2, buf+tmp, 48-tmp);
   if (tmp2>0) tmp += tmp2;
  }
  if (!ok) break;
  tmp = 0;
  sscanf(buf, "%d|%d", &x, &y);
  w.ws_col = x; w.ws_row = y;
  ioctl(ptyfd, TIOCSWINSZ, &w);
 }
 pthread_exit(NULL);
}
void *timewatch()
{
 char buf[2048]; int tmp = 0;
 while (ok)
 {
  usleep(10000); tmp += 10000;
  if (read(f3, buf, 1)>0) tmp = 0;
  if (read(cend[0], buf, 1)>0) ok = 0;
  if (tmp >= 120000000) ok = 0;
 }
 close(ptyfd);
 pthread_kill(t0, SIGINT);
 pthread_kill(t1, SIGINT);
 pthread_kill(t2, SIGINT);
 pthread_exit(NULL);
}
void *inputwatch()
{
 char buf[2048]; int tmp;
 while (ok)
 {
  if ((tmp=read(f0, buf, 2048))>0)
  cwrite(ptyfd, buf, tmp);
 }
 pthread_exit(NULL);
}
void *outputwatch()
{
 char buf[2048]; int tmp; int tmp2;
 while (ok)
 { 
  if ((tmp=read(ptyfd, buf, 2048))>0)
  cwrite(f1, buf, tmp);
 }
 pthread_exit(NULL);
}

void handle_int(num)
{
 return;
}
int main(int argc, char **argv)
{
 if (argc<8)
 {
  fprintf(stderr, "%s [session] [x] [y] [basedir] [term] [] [shell] [cwd]", argv[0]);
  exit;
 } 
 chdir(argv[8]);
 struct sigaction int_handler = {.sa_handler=handle_int};
 sigaction(SIGINT,&int_handler,0);
 sigaction(SIGPIPE,&int_handler,0);
 ourpid = getpid();
 char *session = argv[1];
 char *basedir;
 basedir = argv[4];
 uint32_t x, y;
 x = atoi(argv[2]); y = atoi(argv[3]);
 strncpy(fname0, basedir, 2048);
 strcat(fname0, "/");
 strncat(fname0, session, 2000);
 strcat(fname0, ".input");

 strncpy(fname1, basedir, 2048);
 strcat(fname1, "/");
 strncat(fname1, session, 2000);
 strcat(fname1, ".output");

 strncpy(fname2, basedir, 2048);
 strcat(fname2, "/");
 strncat(fname2, session, 2000);
 strcat(fname2, ".tsize");

 strncpy(fname3, basedir, 2048);
 strcat(fname3, "/");
 strncat(fname3, session, 2000);
 strcat(fname3, ".tstamp");

 mkfifo(fname0, S_IRWXU | S_IRWXG);
 mkfifo(fname1, S_IRWXU | S_IRWXG);
 mkfifo(fname2, S_IRWXU | S_IRWXG);
 mkfifo(fname3, S_IRWXU | S_IRWXG);
 f0 = open(fname0, O_RDWR, S_IRWXU | S_IRWXG);
 f1 = open(fname1, O_RDWR, S_IRWXU | S_IRWXG);
 f2 = open(fname2, O_RDWR, S_IRWXU | S_IRWXG);
 f3 = open(fname3, O_RDWR | O_NONBLOCK, S_IRWXU | S_IRWXG);

 ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);

 w.ws_col=x; w.ws_row=y;

 pipe(cend);
 fcntl(cend[0], F_SETFL, fcntl(cend[0], F_GETFL, 0) | O_NONBLOCK);
 fcntl(cend[1], F_SETFL, fcntl(cend[1], F_GETFL, 0) | O_NONBLOCK);
 
 int pty = forkpty(&ptyfd, NULL, NULL, &w);
 if (!pty)
 {
  close(cend[0]);
  char *environ[] = {"", argv[5], argv[6], NULL};
  int pid = fork();
  if (!pid)
  execle(argv[7], argv[7], NULL, environ);
  {
   wait();
   write(cend[1], "x", 1);
   exit(0);
  }
 }
 close(cend[1]);
 
 pthread_create(&t0, NULL, sizewatch, NULL);
 pthread_create(&t1, NULL, inputwatch, NULL);
 pthread_create(&t2, NULL, outputwatch, NULL);
 pthread_create(&t3, NULL, timewatch, NULL);

 pthread_join(t0, NULL);
 pthread_join(t1, NULL);
 pthread_join(t2, NULL);
 pthread_join(t3, NULL);

 wait();
 
 close(f0); close(f1); close(f2); close(f3); close(ptyfd);

 remove(fname0);
 remove(fname1);
 remove(fname2);
 remove(fname3);

 int t;
 for(t=9;t<=argc;t++)
 remove(argv[t]);
}