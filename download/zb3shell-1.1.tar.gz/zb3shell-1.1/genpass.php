<?php
if ($argc<2)
{
 echo('Specify password!'."\n"); exit;
}
$password = $argv[1];

function hash_for_pw($str)
{
 return sha1(sha1(sha1(strrev(sha1($str))).strrev(sha1(sha1(strrev(md5('()'.sha1(sha1($str).strrev(sha1($str))))))).md5($str)).'zb3'));
}
function hash_for_hash($str)
{
 return sha1(sha1($str).strrev(md5('()'.strrev(sha1(strrev($str).md5(strrev($str.md5(sha1($str)))))).sha1(sha1($str).strrev(sha1($str))))));
}
function hash_for_pw_hash($str)
{
 return sha1(sha1(sha1(strrev(sha1(sha1(strrev(md5('()'.sha1(sha1($str).strrev(sha1($str))))))))).strrev(md5($str)).'zb3'));
}
echo('$pw_c_hash = \''.hash_for_pw($password)."';\n");
echo('$hash_c_hash = \''.hash_for_pw_hash(hash_for_hash($password))."';\n");