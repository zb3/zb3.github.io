gcc termpaint.c -o termpaint -lm
