#include <sys/types.h>
#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <termios.h>
#include <errno.h>
#include <math.h>

unsigned char ch;
char isrunning;
unsigned short xl;
unsigned short yl;
unsigned short x;
unsigned short y;
unsigned int ln = 0;

char *box;
char hid=1;

void erase()
{
 fprintf(stdout, "\r\033[%dA", 666);
}
void repaint()
{
 unsigned int r=0, c=0;
 for(;r<yl;r++)
 {
  for(c=0;c<xl;c++)
  {
   if (c==x && r==y && hid==1)
   {
    if (((r*xl)+c)[box] == 0)
    {
     fprintf(stdout, "_");
    }
    else
    {
     fprintf(stdout, "\033[4m#\033[0m");
    }
   }
   else if (((r*xl)+c)[box] == 0)
   {
    if (((r*xl)+c+1) == ln)
    fprintf(stdout, "_");
    else fprintf(stdout, " ");
   }
   else
   {
    fprintf(stdout, "#");
   }
  } 
  if (r<(yl-1))
  fprintf(stdout, "\n");
 }
 fflush(stdout);
}
void term_fail()
{
 fprintf(stderr, "unable to set terminal characteristics\n");
 perror("");                                                
 exit(1);                                                   
}

int checktty(struct termios *p, int term_fd)
{
 struct termios ck;
 return (tcgetattr(term_fd, &ck) == 0 && (p->c_lflag == ck.c_lflag) && (p->c_cc[VMIN] == ck.c_cc[VMIN]) && (p->c_cc[VTIME] == ck.c_cc[VMIN]));
}
int keypress(int term_fd)
{
 int retval=read(term_fd, &ch, sizeof ch);
 //optional checking here
 return retval;
}
int flush_term(int term_fd, struct termios *p)
{
 struct termios newterm;
 errno=0;
 tcgetattr(term_fd, p);  /* get current stty settings*/
 newterm = *p;  newterm.c_lflag &= ~(ECHO | ICANON); 
 newterm.c_cc[VMIN] = 0;  newterm.c_cc[VTIME] = 0; 
 return(tcgetattr(term_fd, p) == 0 && tcsetattr(term_fd, TCSAFLUSH, &newterm) == 0 && checktty(&newterm, term_fd) != 0);
}
void lineBetween(unsigned int ln1, unsigned int ln2)
{
 unsigned int x1 = (ln1-1)%xl, y1 = ((ln1-1)-x1)/xl, x2 = (ln2-1)%xl, y2 = ((ln2-1)-x2)/xl;
 float x,y,xinc,yinc;
 int dx, dy;
 int k;

 int step;

 dx=x2-x1;
 dy=y2-y1;

 if(abs(dx)>abs(dy))
 step=abs(dx);
 else
 step=abs(dy);
 xinc=(float)dx/step;
 yinc=(float)dy/step;
 x=x1;
 y=y1;

 box[(int)round(x)+((int)round(y)*xl)] = 1;

 for(k=1;k<=step;k++)
 {
  x=x+xinc;
  y=y+yinc;
  box[(int)round(x)+((int)round(y)*xl)] = 1;
 }
}
void wfc(void)
{
 struct timespec tsp={0,500000};  /* sleep 500 usec (or likely more ) */
 struct termios  attr;
 struct termios *p=&attr;
 int term_fd=fileno(stdin);
 fflush(stdout);
 if(!flush_term(term_fd, p))
 term_fail();
 while (isrunning)
 {
  nanosleep(&tsp, NULL);
  switch(keypress(term_fd))
  {
   case 0:
   default:
   break;
   case -1:
   fprintf(stdout, "Read error %s", strerror(errno));
   exit(1);
   break;
   case 1:
   if (ch==113)
   {
    isrunning=0;
   }
   else if (ch==104)
   {
    hid = -hid;
    erase();
    repaint();
   }
   else if (ch==32)
   {
    (x+(y*xl))[box] = ((x+(y*xl))[box])?0:1;
    erase();
    repaint();
   }
   else if (ch==65 && y>0)
   {
    y--;
    erase();
    repaint();
   }
   else if (ch==66 && y<(yl-1))
   {
    y++;
    erase();
    repaint();
   }
   else if (ch==68 && x>0)
   {
    x--;
    erase();
    repaint();
   }
   else if (ch==67 && x<(xl-1))
   {
    x++;
    erase();
    repaint();
   }
   else if (ch==108)
   {
    if (ln)
    {
     if (ln != ((x+(y*xl))+1))
     lineBetween(ln, (x+(y*xl))+1);
     ln = 0;
    }
    else
    {
     ln = (x+(y*xl))+1;
    }
    erase();
    repaint();
   }
   break;                 
  } 
 }
 if(tcsetattr(term_fd, TCSADRAIN, p) == -1 && tcsetattr(term_fd, TCSADRAIN, p) == -1)
 term_fail();
}
int main()
{
 isrunning=1;
 struct winsize w;
 ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
 xl = w.ws_col;
 yl = w.ws_row;
 x=0; y=0;
 box = malloc(w.ws_col*w.ws_row);
 unsigned int l;
 while(l<(w.ws_col*w.ws_row))
 {
  l[box] = 0;
  l++;
 }
 repaint();
 wfc();
}
