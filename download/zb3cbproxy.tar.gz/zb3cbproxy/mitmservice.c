#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <pthread.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <signal.h>
#include <fcntl.h>
#define MAX(a,b) (((a)>(b))?(a):(b))

typedef unsigned char byte;
int one = 1, rocket, l80;
int runningthreads = 0, init;
pthread_mutex_t rt = PTHREAD_MUTEX_INITIALIZER;
int onnet[14024];
unsigned short num=0, rnum=0;

typedef struct
{
 int net;
 int net2;
} nets;

void killmeh(int pocoto)
{
 fcntl(l80, F_SETFL, fcntl(l80, F_GETFL, 0) | O_NONBLOCK);
 int ns=1;
 while(ns >= 0)
 {
  ns = accept(l80, (struct sockaddr*)NULL, NULL);
 } 
 shutdown(l80, SHUT_RDWR);
 close(l80);

 shutdown(init, SHUT_RDWR);
 close(init);
}

void *ffclient(void *arg)
{
 pthread_mutex_lock(&rt);
 runningthreads++;
 pthread_mutex_unlock(&rt);

 char o;

 int net = (int)arg;
 if (write(rocket, &o, 1)<=0)
 {killmeh(1); goto TOUT;}

 struct timeval tv; fd_set fds;
 int net2;

 while (1)
 {
  tv.tv_sec = 5; tv.tv_usec=0;

  FD_ZERO(&fds); 
  FD_SET(l80, &fds);
 
  if (select(l80+1, &fds, NULL, NULL, &tv)>0)
  {
   if (!FD_ISSET(l80, &fds))
   goto TOUT;
  } else goto TOUT;
 
  net2 = accept(l80, (struct sockaddr*)NULL, NULL);

  tv.tv_sec = 0; tv.tv_usec=0;

  FD_ZERO(&fds);
  FD_SET(net2, &fds);

  if (select(net2+1, &fds, NULL, NULL, &tv)>0)
  {
   if (!FD_ISSET(net2, &fds))
   break;
  } else break;
 }
 
 tv.tv_sec = 4; tv.tv_usec = 0;

 FD_ZERO(&fds);
 FD_SET(net, &fds);
 FD_SET(net2, &fds);

 byte buffer[2048]; int nbytes = 1;

 while (select(MAX(net, net2)+1, &fds, NULL, NULL, &tv))
 {
  tv.tv_sec = 4; tv.tv_usec = 0;
  if (FD_ISSET(net, &fds))
  {
   nbytes = read(net, buffer, 2048);
   if (nbytes > 0)
   {
    write(net2, buffer, nbytes);
   }
   else {shutdown(net2, SHUT_RDWR);close(net2);shutdown(net, SHUT_RDWR);close(net); break;}
  }
  if (FD_ISSET(net2, &fds))
  {
   nbytes = read(net2, buffer, 2048);
   if (nbytes > 0)
   {
    write(net, buffer, nbytes);
   }
   else {shutdown(net2, SHUT_RDWR);close(net2);shutdown(net, SHUT_RDWR);close(net); break;}
  }
  FD_ZERO(&fds);
  FD_SET(net, &fds);
  FD_SET(net2, &fds);
 } 
 
 shutdown(net, SHUT_RDWR); close(net);
 shutdown(net2, SHUT_RDWR); close(net2);
 
 TOUT:
 pthread_mutex_lock(&rt);
 runningthreads--;
 pthread_mutex_unlock(&rt);
 pthread_exit(NULL);
}

int main(int argc, char **argv)
{
 if (argc<3)
 {
  fprintf(stderr, "%s [remote port] [local port]\n", argv[0]); fflush(stderr);
  exit(0);
 }
 signal(SIGINT, killmeh);
 signal(SIGPIPE, SIG_IGN);

 int newclient = 0;
 struct sockaddr_in6 init_addr = {0}; 
 struct sockaddr_in6 l80_addr = {0}; 
 
 init = socket(AF_INET6, SOCK_STREAM, 0);
 one = 1;
 setsockopt(init, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));

 init_addr.sin6_family = AF_INET6;
 init_addr.sin6_addr = in6addr_any;
 init_addr.sin6_port = htons(atoi(argv[1]));

 bind(init, (struct sockaddr*)&init_addr, sizeof(init_addr)); 
 listen(init, 1);
 
 rocket = accept(init, (struct sockaddr*)NULL, NULL);
 if (rocket < 0)
 {shutdown(init, SHUT_RDWR); close(init); return;}
 close(init);

 l80_addr = init_addr;

 init = socket(AF_INET6, SOCK_STREAM, 0);
 one = 1; setsockopt(init, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
 init_addr.sin6_port = htons(atoi(argv[2]));
 bind(init, (struct sockaddr*)&init_addr, sizeof(init_addr)); 
 listen(init, 5);
 
 l80 = socket(AF_INET6, SOCK_STREAM, 0);
 one = 1; setsockopt(l80, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
 bind(l80, (struct sockaddr*)&l80_addr, sizeof(l80_addr)); 
 listen(l80, 1);

 while(1)
 {
  while(runningthreads>16)
  {
   usleep(8000);
  }
  newclient = accept(init, (struct sockaddr*)NULL, NULL);
  if (newclient>=0)
  {
   pthread_t new;
   pthread_create(&new, (void *)NULL, ffclient, (void *)newclient); //hack: sizeof(int)<=sizeof(void *)
   pthread_detach(new);
  } else break;
 }
 while (runningthreads)
 {
  usleep(10000);
 }
 return 0;
}