gcc mitmservice.c -o mitmservice -lpthread
gcc zproxy.c -o zproxy -lpthread
gcc rocketnofork.c -o rocketnofork -lpthread