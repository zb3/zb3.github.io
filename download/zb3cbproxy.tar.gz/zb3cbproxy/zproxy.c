#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <pthread.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <fcntl.h>
#include <signal.h>
#define MAX(a,b) (((a)>(b))?(a):(b))

int runningthreads = 0;
pthread_mutex_t rt = PTHREAD_MUTEX_INITIALIZER;;
typedef unsigned char byte;

//same as read, but reads no less than count bytes
char cread(int fd, void *buf, size_t count)
{
 //select...
 struct timeval tv; fd_set readfds;
 tv.tv_sec = 5; tv.tv_usec=0;

 FD_ZERO(&readfds);
 FD_SET(fd, &readfds);

 if (select(fd+1, &readfds, NULL, NULL, &tv)>0)
 {
  if (!FD_ISSET(fd, &readfds))
  goto FAIL;
 }
 else
 {
  goto FAIL;
 }
 
 size_t tbytes = 0; int tmp;
 while(tbytes<count)
 {
  tmp = read(fd, buf+tbytes, count-tbytes);
  if (tmp>0)
  tbytes += tmp;
  else goto FAIL;
 }
 return 1;
 FAIL:
 shutdown(fd, SHUT_RDWR);
 close(fd);
 return 0;
}

int tconnect(int sockfd, const struct sockaddr *addr, socklen_t addrlen, int timeout)
{
 fd_set towrite; int flags;
 struct timeval tv;
 tv.tv_sec = timeout; tv.tv_usec = 0;

 FD_ZERO(&towrite);
 FD_SET(sockfd, &towrite);

 if ((flags = fcntl(sockfd, F_GETFL, 0)) < 0)
 return -1;

 if (fcntl(sockfd, F_SETFL, flags | O_NONBLOCK) < 0)
 return -1;

 if (!connect(sockfd, addr, addrlen))
 goto OK;
 else if (errno != EINPROGRESS) return -1;
 
 if (select(sockfd+1, NULL, &towrite, NULL, &tv))
 {
  if (FD_ISSET(sockfd, &towrite))
  goto OK;
 }

 fcntl(sockfd, F_SETFL, flags);
 return -1;

 OK:
 fcntl(sockfd, F_SETFL, flags);
 return 0; 
}

char contains(const char *str, char what)
{
 int e;
 for(e=0;e<strlen(str);e++)
 if (str[e]==what)
 return 1;
 return 0;
}

void *clientproc(void *arg)
{
 pthread_mutex_lock(&rt);
 runningthreads++;
 pthread_mutex_unlock(&rt);

 int net = (int)arg, clause, net2;
 pthread_t reader, writer;

 byte client[262] = {0}; byte cm = 0;

 if (!cread(net, client, 2))
 goto EXIT;

 for(cm=0;cm<client[1];cm++)
 {
  if (!cread(net, client, 1))
  goto EXIT;
 }

 client[0] = 5; client[1] = 0;
 if (write(net, client, 2)<0)
 goto EXIT;

 if (!cread(net, client, 4))
 goto EXIT;

 clause = 1;
 byte actlen = 0;

 if (client[3] == 1)
 {
  net2 = socket(AF_INET, SOCK_STREAM, 0);
  struct sockaddr_in host_addr = {0};
  if (!cread(net, client+4, 6))
  goto EXIT;
  host_addr.sin_family = AF_INET;
  host_addr.sin_port = *(unsigned short*)(client+8);
  host_addr.sin_addr = *(struct in_addr*)(client+4);
  clause = tconnect(net2, (struct sockaddr *)&host_addr, sizeof(host_addr), 5);
  actlen = 10;
 }
 else if (client[3] == 4)
 {
  net2 = socket(AF_INET6, SOCK_STREAM, 0);
  struct sockaddr_in6 host_addr = {0};
  if (!cread(net, client+4, 18))
  goto EXIT;
  host_addr.sin6_family = AF_INET6;
  host_addr.sin6_port = *(unsigned short*)(client+20);
  host_addr.sin6_addr = *(struct in6_addr*)(client+4);
  clause = tconnect(net2, (struct sockaddr *)&host_addr, sizeof(host_addr), 5);
  actlen = 22;
 }
 else //domain name
 {
  //use getaddrinfo because it can handle ipv6
  struct addrinfo addr = {0}, *caddr2;
  addr.ai_family = AF_UNSPEC;
  addr.ai_socktype = SOCK_STREAM;
  if (!cread(net, client+4, 1))
  goto EXIT;
  if (!cread(net, client+5, client[4]))
  goto EXIT;
  client[5+client[4]] = 0;
  if (getaddrinfo((char *)client+5, (char *)NULL, &addr, &caddr2))
  {
   clause=1;
  }
  else
  {
   if (!cread(net, client+5+client[4], 2))
   goto EXIT;
   if (caddr2->ai_family == AF_INET)
   {
    net2 = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in host_addr = {0};
    host_addr.sin_family = AF_INET;
    host_addr.sin_port = *(unsigned short*)(client+client[4]+5);
    host_addr.sin_addr = ((struct sockaddr_in*)(caddr2->ai_addr))->sin_addr;
    clause = tconnect(net2, (struct sockaddr *)&host_addr, sizeof(host_addr), 5);
   }
   else if (caddr2->ai_family == AF_INET6)
   {
    net2 = socket(AF_INET6, SOCK_STREAM, 0);
    struct sockaddr_in6 host_addr = {0};
    host_addr.sin6_family = AF_INET6;
    host_addr.sin6_port = *(unsigned short*)(client+client[4]+5);
    host_addr.sin6_addr = ((struct sockaddr_in6*)(caddr2->ai_addr))->sin6_addr;
    char str2[INET6_ADDRSTRLEN];
    inet_ntop(AF_INET6, &(host_addr.sin6_addr), str2, INET6_ADDRSTRLEN);
    clause = tconnect(net2, (struct sockaddr *)&host_addr, sizeof(host_addr), 5);
   } else clause=1;
   freeaddrinfo(caddr2);
  }
  actlen = client[4]+7;
 }

 if (!clause)
 {
  client[1] = 0;
  if (write(net, client, actlen)<0)
  {shutdown(net2, SHUT_RDWR); close(net2);goto EXIT;}

  struct timeval tv; fd_set fds;
  tv.tv_sec = 4; tv.tv_usec = 0;

  FD_ZERO(&fds);
  FD_SET(net, &fds);
  FD_SET(net2, &fds);

  byte buffer[2048]; int nbytes = 1;

  while (select(MAX(net, net2)+1, &fds, NULL, NULL, &tv))
  {
   tv.tv_sec = 4; tv.tv_usec = 0;
   if (FD_ISSET(net, &fds))
   {
    nbytes = read(net, buffer, 2048);
    if (nbytes > 0)
    {
     write(net2, buffer, nbytes);
    }
    else {shutdown(net2, SHUT_RDWR);close(net2);shutdown(net, SHUT_RDWR);close(net); break;}
   }
   if (FD_ISSET(net2, &fds))
   {
    nbytes = read(net2, buffer, 2048);
    if (nbytes > 0)
    {
     write(net, buffer, nbytes);
    }
    else {shutdown(net2, SHUT_RDWR);close(net2);shutdown(net, SHUT_RDWR);close(net); break;}
   }
   FD_ZERO(&fds);
   FD_SET(net, &fds);
   FD_SET(net2, &fds);
  }
  shutdown(net, SHUT_RDWR); close(net);
  shutdown(net2, SHUT_RDWR); close(net2);
 } 
 else
 {
  client[1] = 1;
  write(net, client, actlen); 
  close(net);
 }
 EXIT:
 pthread_mutex_lock(&rt);
 runningthreads--;
 pthread_mutex_unlock(&rt);
 pthread_exit(NULL);
}

int main(int argc, char **argv)
{
 signal(SIGPIPE, SIG_IGN);
 signal(SIGABRT, SIG_IGN);
 if (argc<2)
 {
  fprintf(stderr, "%s [port]", argv[0]); fflush(stderr);
  return 0;
 }

 int ll; struct sockaddr_in6 serv_addr = {0};

 ll = socket(AF_INET6, SOCK_STREAM, 0);
 serv_addr.sin6_family = AF_INET6;
 serv_addr.sin6_port = htons(atoi(argv[1]));
 int one = 1; setsockopt(ll, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
 bind(ll, (struct sockaddr*)&serv_addr, sizeof(serv_addr)); 
 listen(ll, 5);

 int client = 1;
 while(client >= 0)
 {
  while(runningthreads>16)
  {
   usleep(8000);
  }
  client = accept(ll, (struct sockaddr*)NULL, NULL);
  if (client >= 0)
  {
   pthread_t new;
   while (pthread_create(&new, (void *)NULL, clientproc, (void *)client))
   {usleep(50000);}
   pthread_detach(new);
  }
 }
}