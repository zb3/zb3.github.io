#include <sys/types.h>
#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <termios.h>
#include <errno.h>
#include <math.h>

#define NEAR 9.20
#define DIST 6

typedef struct _vertices {
 float x;
 float y;
 float z;
} vertices;

typedef struct _edges {
 unsigned char a;
 unsigned char b;
} edge;

//this needs to be "proper" width & height, height must be equal to width
unsigned short width = 45;
unsigned short height = 45;
unsigned short allwidth = 0;
unsigned short allheight = 0;
char mode1;
float corr = 1.754;

char *pixels;
vertices verts[8] = {{ -1, -1, -1 }, { -1, -1,  1 }, { -1,  1, -1 }, { -1,  1,  1 }, {  1, -1, -1 },  {  1, -1,  1 }, {  1,  1, -1 }, {  1,  1,  1 }};
vertices rotated[8];
edge edges[12] = {{0, 1}, {0, 2}, {0, 4}, {1, 3}, {1, 5}, {2, 3}, {2, 6}, {3, 7}, {4, 5}, {4, 6}, {5, 7}, {6, 7}};
double a = 0.0, b=0.0, c=0.0;
double as = 0.0, bs=0.0, cs=0.0;
char running=1;
unsigned char ch;

void getMetrics()
{
 struct winsize w;
 ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
 allwidth = w.ws_col;
 allheight = w.ws_row;
 if ((w.ws_row*corr)<=(w.ws_col))
 {
  mode1 = 1;
  width = w.ws_row*corr;
  height = w.ws_row; 
 }
 else
 {
  width = w.ws_col;
  height = w.ws_col; 
 }
 if (w.ws_xpixel>0)
 {
  corr = ((float)w.ws_col/(float)w.ws_xpixel)/((float)w.ws_row/(float)w.ws_ypixel);
 }
}

void updateMetrics()
{
 unsigned int osize = width*height;
 getMetrics();
 if (width*height > osize)
 {
  pixels = realloc(pixels, width*height); 
 }
}

void rotateCube()
{
 unsigned char i=0; float t1, t2;
 for(;i<8;i++)
 {
  rotated[i].x = verts[i].x*cos(a) - verts[i].y*sin(a);
  rotated[i].y = verts[i].y*cos(a) + verts[i].x*sin(a);
 
  t1 = rotated[i].x;
  rotated[i].x = t1*cos(b) - verts[i].z*sin(b);
  rotated[i].z = verts[i].z*cos(b) + t1*sin(b);

  t1 = rotated[i].y;  t2 = rotated[i].z;
  rotated[i].y = t1*cos(c) - t2*sin(c);
  rotated[i].z = t2*cos(c) + t1*sin(c);


  
 }
}
void addLine(unsigned int x1, unsigned int y1, unsigned int x2, unsigned int y2)
{
 float x,y,xinc,yinc;
 int dx, dy;
 int k;

 int step;

 dx=x2-x1;
 dy=y2-y1;

 if(abs(dx)>abs(dy))
 step=abs(dx);
 else
 step=abs(dy);
 xinc=(float)dx/step;
 yinc=(float)dy/step;
 x=x1;
 y=y1;

 pixels[(int)round(x)+((int)round(y)*width)] = 1;

 for(k=1;k<=step;k++)
 {
  x=x+xinc;
  y=y+yinc;
  pixels[(int)round(x)+((int)round(y)*width)] = 1;
 }
}
void projectCube()
{
 unsigned char i=0; float t1, t2, t3, t4;
 for(;i<12;i++)
 {
  t1 = (rotated[edges[i].a].x*NEAR)/(rotated[edges[i].a].z + NEAR + DIST);
  t2 = (rotated[edges[i].a].y*NEAR)/(rotated[edges[i].a].z + NEAR + DIST);
  t3 = (rotated[edges[i].b].x*NEAR)/(rotated[edges[i].b].z + NEAR + DIST);
  t4 = (rotated[edges[i].b].y*NEAR)/(rotated[edges[i].b].z + NEAR + DIST);
  if (mode1)
  {
   addLine((int)round(((t1+1.18)*(width/2.4))), (int)round((((t2+(1.18))*(width/2.4))/corr)), (int)round(((t3+1.18)*(width/2.4))), (int)round((((t4+(1.18))*(width/2.4)))/corr));
  }
  else
  {
   addLine((int)round(((t1+1.18)*(width/2.4))), (int)round((((t2+(1.18*corr))*(width/2.4))/corr)), (int)round(((t3+1.18)*(width/2.4))), (int)round((((t4+(1.18*corr))*(width/2.4)))/corr));
  }
 }
}

void erase()
{
 fprintf(stdout, "\r\033[%dA", allheight);
 fflush(stdout);
}
void clearpixmap2()
{
 unsigned int i;
 for(i=0; i<(width*height); i++)
 {
  pixels[i] = 0;
 }
}
void print()
{
 unsigned short r=0, c, v, n;
 for(n=0; n<((allheight-width)/2); n++)
 {
  fprintf(stdout, "\n");
 }
 for(;r<height;r++)
 {
  for(v=0; v<((allwidth-width)/2); v++)
  fprintf(stdout, " ");
  for(c=0;c<width;c++)
  {
   if (pixels[c+(width*r)])
   fprintf(stdout, "z");
   else
   fprintf(stdout, " ");
  }
  for(v=v+c; v<(allwidth); v++)
  fprintf(stdout, " ");
  if (r<(height-1))
  fprintf(stdout, "\n");
 }
 for(n+=r; n<(allheight); n++)
 fprintf(stdout, "\n");
 fflush(stdout);
}
void term_fail()
{
 fprintf(stderr, "unable to set terminal characteristics\n");
 perror("");                                                
 exit(1);                                                   
}

int checktty(struct termios *p, int term_fd)
{
 struct termios ck;
 return (tcgetattr(term_fd, &ck) == 0 && (p->c_lflag == ck.c_lflag) && (p->c_cc[VMIN] == ck.c_cc[VMIN]) && (p->c_cc[VTIME] == ck.c_cc[VMIN]));
}
int keypress(int term_fd)
{
 int retval=read(term_fd, &ch, sizeof ch);
 //optional checking here
 return retval;
}
int flush_term(int term_fd, struct termios *p)
{
 struct termios newterm;
 errno=0;
 tcgetattr(term_fd, p);  /* get current stty settings*/
 newterm = *p;  newterm.c_lflag &= ~(ECHO | ICANON); 
 newterm.c_cc[VMIN] = 0;  newterm.c_cc[VTIME] = 0; 
 return(tcgetattr(term_fd, p) == 0 && tcsetattr(term_fd, TCSAFLUSH, &newterm) == 0 && checktty(&newterm, term_fd) != 0);
}
void wfc(void)
{
 struct timespec tsp={0,51212600};  /* sleep 500 usec (or likely more ) */
 struct termios  attr;
 struct termios *p=&attr;
 int term_fd=fileno(stdin);
 fflush(stdout);
 if(!flush_term(term_fd, p))
 term_fail();
 while (running==1)
 {
  nanosleep(&tsp, NULL);
  switch(keypress(term_fd))
  {
   case 0:
   default:
   break;
   case -1:
   fprintf(stdout, "Read error %s", strerror(errno));
   exit(1);
   case 1:
   if (ch==113)
   {
    running=0;
   }
   else if (ch==65)
   {
    cs = cs+0.01;
   }
   else if (ch==66)
   {
    cs = cs-0.01;
   }
   else if (ch==68)
   {
    bs = bs+0.01;
   }
   else if (ch==67)
   {
    bs = bs-0.01;
   }               
  }
  b = b+bs;
  if (b>3.14)
  b = b-3.14;
  if (b<-3.14)
  b = b+3.14;
  c = c+cs;
  if (c>3.14)
  c = c-3.14;
  if (c<-3.14)
  c = c+3.14;
  clearpixmap2();
  updateMetrics();
  rotateCube();
  projectCube();
  erase();
  print();
 }
 if(tcsetattr(term_fd, TCSADRAIN, p) == -1 && tcsetattr(term_fd, TCSADRAIN, p) == -1)
 term_fail();
}
int main()
{
 getMetrics();
 pixels = malloc(width*height); unsigned short i=0;
 for(; i<width*height; i++)
 i[pixels] = 0;
 wfc();
 free(pixels);
 return 0;
}
