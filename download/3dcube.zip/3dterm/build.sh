gcc termcube.c -o termcube -lm
