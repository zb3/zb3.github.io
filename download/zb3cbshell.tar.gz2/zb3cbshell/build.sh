gcc mycli.c -o mycli -lpthread
gcc myserv.c -o myserv -lpthread -lutil