#include <sys/types.h>
#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <termios.h>
#include <errno.h>

typedef struct _thetab
{
 char *name;
 unsigned char ntab;
 struct _thetab *children;
 unsigned char numchil;
} thetab;

typedef struct _tabcontent
{
 char *text;
} tabcontent;

thetab tab1c[] = {{"mtab1", 3, NULL, 0}, {"mtab2", 4, NULL, 0}};
thetab tab2c[] = {{"mtab3", 5, NULL, 0}, {"mtab4", 6, NULL, 0}, {"mtab5", 7, NULL, 0}};
thetab maintabs[] = {{"tab1", 0, tab1c, 2}, {"tab2", 1, tab2c, 3}, {"tab3", 2, NULL, 0}};

unsigned char ch;

tabcontent content[] = {NULL, NULL, {"tab3 content"}, {"trololo"}, {"zb3 fail"}, {"loltest"}, {"mtab4??"}, {"lolme"}};

unsigned char pos[] = {2, 0};
unsigned char numlevel = 2;
unsigned char levelon = 0;

thetab* getTab(unsigned char level, unsigned char p)
{
 thetab *found; unsigned char levelnow = 0; unsigned char maxchilds = 0;
 found = maintabs; maxchilds = 3; //WARNING!!! hardcoded
 while(levelnow<level)
 {
  if (pos[levelnow]>=maxchilds)
  {
   return NULL;
  }
  maxchilds = found[pos[levelnow]].numchil;
  found = found[pos[levelnow]].children;
  if (found == NULL || maxchilds==0)
  {
   return NULL;
  }
  levelnow++;
 }
 if (p<maxchilds)
 return found+p;
 else
 return NULL;
}
unsigned char mhr() //important function!
{
 unsigned char h = 0; thetab *temp=NULL;
 temp = getTab(h, 0);
 while (temp != NULL)
 {
  h++;
  temp = getTab(h, 0);
 }
 return h;
}
unsigned char mvr() //max vertical rows
{
 unsigned char h = 0, v = 0, gv = 0, nl = mhr(); thetab *temp=NULL;
 for(;h<nl;h++)
 {
  v = 0; temp = getTab(h, v);
  while(temp != NULL)
  {
   v++;
   temp = getTab(h, v);
  }
  gv = (v>gv)?v:gv;
 }
 return gv;
}

void resetPos()
{
 unsigned char i=levelon+1, nl = mhr();
 for(;i<nl;i++)
 pos[i] = 0;
}
void paintCol(unsigned char style, unsigned char width, char *text)
{
 if (style==0)
 {
  fprintf(stdout, "\033[47;30m");
 }
 else if (style==1)
 {
  fprintf(stdout, "\033[7m");
 }
 fprintf(stdout, text);
 unsigned char tl;
 for(tl=strlen(text); tl<width; tl++)
 fprintf(stdout, " ");
 fprintf(stdout, "\033[0m");
}
void paintBlank()
{
 unsigned char i;
 for(i=0; i<21; i++)
 fprintf(stdout, " ");
}
void paint()
{
 unsigned char i=0, v=0, mhr2 = mhr(), mvr2 = mvr(); thetab *curr; char temp[256];
 for(v=0; v<mhr2; v++)
 {
  if (v==0)
  {
   paintCol(0, 20, "Main Menu:");
   fprintf(stdout, " ");
  }
  else
  {
   curr = getTab((v-1), pos[v-1]);
   sprintf(temp, "%s Menu:", curr->name);
   paintCol(0, 20, temp);
   fprintf(stdout, " ");
  }
 }
 curr = getTab((mhr2-1), pos[(mhr2-1)]);
 sprintf(temp, "%s", curr->name);
 struct winsize w;
 ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);

 paintCol(0, (w.ws_col)-(mhr2*21), temp);
 fprintf(stdout, "\n");
 for(;i<mvr2;i++)
 {
  for(v=0; v<mhr2; v++) 
  {
   if (getTab(v, i) == NULL)
   {
    paintBlank();
    continue;
   }
   if (pos[v] == i && levelon == v)
   {
    curr = getTab(v, i);
    paintCol(1, 20, curr->name);
   } 
   else if (pos[v] == i)
   {
    curr = getTab(v, i);
    paintCol(0, 20, curr->name);
   }
   else
   {
    curr = getTab(v, i);
    paintCol(2, 20, curr->name);
   }
   fprintf(stdout, " ");
  }
  if (i==0)
  {
   curr = getTab((mhr2-1), pos[(mhr2-1)]);
   fprintf(stdout, "%s", content[curr->ntab]);
  }
  fprintf(stdout, "\033[K\n");
 }
 fflush(stdout);
}
unsigned char running=1;
//begin terminal stuff
void term_fail()
{
 fprintf(stderr, "unable to set terminal characteristics\n");
 perror("");                                                
 exit(1);                                                   
}

int checktty(struct termios *p, int term_fd)
{
 struct termios ck;
 return (tcgetattr(term_fd, &ck) == 0 && (p->c_lflag == ck.c_lflag) && (p->c_cc[VMIN] == ck.c_cc[VMIN]) && (p->c_cc[VTIME] == ck.c_cc[VMIN]));
}
int keypress(int term_fd)
{
 int retval=read(term_fd, &ch, sizeof ch);
 return retval;
}
int flush_term(int term_fd, struct termios *p)
{
 struct termios newterm;
 errno=0;
 tcgetattr(term_fd, p);
 newterm = *p;  newterm.c_lflag &= ~(ECHO | ICANON); 
 newterm.c_cc[VMIN] = 0;  newterm.c_cc[VTIME] = 0; 
 return(tcgetattr(term_fd, p) == 0 && tcsetattr(term_fd, TCSAFLUSH, &newterm) == 0 && checktty(&newterm, term_fd) != 0);
}
void erase(unsigned char n)
{
 fprintf(stdout, "\033[K\r\033[%dA\033[K", n);
}
void wfc(void)
{
 struct timespec tsp={0,500};
 struct termios  attr;
 struct termios *p=&attr;
 int term_fd=fileno(stdin);
 fflush(stdout);
 if(!flush_term(term_fd, p))
 term_fail();
 while (running==1)
 {
  nanosleep(&tsp, NULL);
  switch(keypress(term_fd))
  {
   case 0:
   default:
   break;
   case -1:
   fprintf(stdout, "Read error %s", strerror(errno));
   exit(1);
   break;
   case 1:
   if (ch==113)
   {
    running=0;
   }
   else if (ch==65 && pos[levelon])
   {
    resetPos();
    pos[levelon] = pos[levelon] -1;
   }
   else if (ch==66 && getTab(levelon, pos[levelon]+1))
   {
    resetPos();
    pos[levelon]++;
   }
   else if (ch==68 && levelon>0)
   {
    levelon--;
   }
   else if (ch==67 && levelon<(mhr()-1))
   {
    levelon++;
   }
   erase(mvr()+1);
   paint();
   break;                 
  } 
 }
 if(tcsetattr(term_fd, TCSADRAIN, p) == -1 && tcsetattr(term_fd, TCSADRAIN, p) == -1)
 term_fail();
}
int main()
{
 paint();
 wfc();
 return 0;
}
