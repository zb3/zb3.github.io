gcc tabsstruct.c -o tabsstruct
