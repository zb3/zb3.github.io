gcc -g `pkg-config --cflags --libs gtk+-2.0`  -o gtktest gtktest.c -lpthread
