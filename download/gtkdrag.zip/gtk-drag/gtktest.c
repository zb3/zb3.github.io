#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>
static void
gtk_fixed_remove (GtkContainer *container,
		  GtkWidget    *widget)
{
  GtkFixed *fixed;
  GtkFixedChild *child;
  GList *children;

  g_return_if_fail (container != NULL);
  g_return_if_fail (GTK_IS_FIXED (container));
  g_return_if_fail (widget != NULL);

  fixed = GTK_FIXED (container);

  children = fixed->children;
  while (children)
    {
      child = children->data;

      if (child->widget == widget)
	{
	  gtk_widget_unparent (widget);
	  fixed->children = g_list_remove_link (fixed->children, children);
	  g_list_free (children);
	  g_free (child);
	  //if (GTK_WIDGET_VISIBLE (widget) && GTK_WIDGET_VISIBLE (container))
	  //  gtk_widget_queue_resize (GTK_WIDGET (container));
	  break;
	}

      children = children->next;
    }
}

static const GtkTargetEntry target_list = {"zb3/tab", 0, 0};

void onthebutton(GtkWidget *button, GdkEventButton *event);
void offthebutton();
void tabmotion(GtkWidget *widget, GdkEventMotion *event, gpointer dframe);

struct DATA {char tname[32]; gint ptx; gint pty;};
struct tabData {char tname[32]; GtkWidget *twidget;};
GtkWidget *draggedtab;
char draggedpos=6;

struct DATA globalargs;

struct tabData *tabargs;
char tcount;

char isdown = 0;
char ishidden = 0;
char fakerequest = 0;
char recv = 0;
gint ptx = 0;
gint pty = 0;
char sd = 0;
char runningthreads = 0;

GtkWidget *window;
GtkWidget *fixed;
GtkWidget *dframecopy;
GtkTargetList *tl;
GdkDragContext *globalcontext;
GdkPixbuf *dragicon = NULL;

//fake request means app only wants the source to set the icon, coz dest cant do this

void check_and_die()
{
 FILE *test;
 while(1)
 {
  struct timespec tsp={0,500};
  nanosleep(&tsp, NULL);
  if ((test = fopen(".zb3dnd2", "r"))!=NULL)
  {
   fclose(test);
  }
  else
  {
   break;
  }
 }
 exit(0); //bye ;)
}
void wait_and_die()
{
 gtk_widget_hide(window);
 pthread_t wait;
 FILE *test;
 if ((test = fopen(".zb3dnd2", "wb"))!=NULL)
 {
  fwrite(&wait, 1, sizeof(pthread_t), test);
  fclose(test);
 }
 pthread_create(&wait, NULL, check_and_die, (void *)NULL);
}
char is_fake_request()
{
 FILE *fakefile;
 fakefile = fopen(".zb3dnd", "rb");
 if (fakefile != NULL)
 {
  char tmp;
  fread(&tmp, 1, 1, fakefile);
  fclose(fakefile);
  if (tmp == 'z')
  return 1;
 }
 return 0;
}
void setup_fake_request(GdkDragContext *context, guint t)
{
 FILE *fakefile;
 fakefile = fopen(".zb3dnd", "wb");
 if (fakefile != NULL)
 {
  fwrite("z", 1, 1, fakefile);
  fclose(fakefile);  
  fakerequest = 1;
  GdkAtom target_type;
  target_type = GDK_POINTER_TO_ATOM(g_list_nth_data(context->targets, 0));
  gtk_drag_get_data(dframecopy, context, target_type, t);
 }
}
void destroy_fake_request()
{
 remove(".zb3dnd"); 
}
void saveArgsToFile()
{
 FILE *file;
 file = fopen(".zb3dnd", "wb");
 if (file != NULL)
 {
  fwrite("t", 1, 1, file);
  fwrite(&globalargs, 1, sizeof(globalargs), file);
  fclose(file);
 }
}
char readArgsFromFile()
{
 FILE *file;
 file = fopen(".zb3dnd", "rb");
 if (file != NULL)
 {
  char tmp;
  fread(&tmp, 1, 1, file);
  if (tmp == 't')
  {
   if (fread(&globalargs, 1, sizeof(globalargs), file)==sizeof(globalargs))
   {
    fclose(file);
    return 1;
   }
  }
  fclose(file);
 }
 return 0;
}
void dumpblock(unsigned char *object, unsigned int size)
{
 unsigned int n = 0;
 static int dump = 0;
 fprintf(stdout, "\nDumping block #%d:\n", dump);
 for(n=0; n < size; n++)
 {
  fprintf(stdout, "%x", object[n]);
 }
 dump++;
 fprintf(stdout, "\n==END OF BLOCK DUMP==");
 fflush(stdout);
}
void tupdate()
{
 char i;
 for(i=0; i<tcount; i++)
 {
  //if (i!=draggedpos)
  //{ 
   gtk_fixed_move(GTK_FIXED(fixed), tabargs[i].twidget, 30+(80*i), 60);
  //}
 }
}
void generateglobalargs()
{
 strcpy(globalargs.tname, gtk_button_get_label(GTK_BUTTON(draggedtab)));
 globalargs.ptx = ptx;
 globalargs.pty = pty;
}
void removetab()
{
 gtk_fixed_remove(GTK_CONTAINER(fixed), draggedtab);
 draggedtab = NULL;
 tcount--;
 char i;
 for(i=draggedpos;i<tcount;i++)
 {
  memcpy(tabargs+(i), tabargs+((i+1)), sizeof(struct tabData));
 }
 tupdate();
 //tabargs = realloc(tabargs, tcount*sizeof(struct tabData));
}
void makeTab(char pos, char *name)
{
 tabargs[pos].twidget = gtk_button_new_with_label(name);
 gtk_widget_set_events(tabargs[pos].twidget, GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK | GDK_POINTER_MOTION_MASK); 
 gtk_widget_set_size_request(tabargs[pos].twidget, 75, 23);
 gtk_fixed_put(GTK_FIXED(fixed), tabargs[pos].twidget, 30+(80*pos), 60);
 g_signal_connect(G_OBJECT(tabargs[pos].twidget), "button-press-event", G_CALLBACK(onthebutton), NULL);
 g_signal_connect(G_OBJECT(tabargs[pos].twidget), "button-release-event", G_CALLBACK(offthebutton), NULL);
 g_signal_connect(G_OBJECT(tabargs[pos].twidget), "motion-notify-event", G_CALLBACK(tabmotion), dframecopy);
 gtk_widget_show(tabargs[pos].twidget);
}
void generateSampleTabs()
{
 tabargs = malloc(4*sizeof(struct tabData));
 makeTab(0, "lol1");
 makeTab(1, "lol2");
 makeTab(2, "lol3");
 makeTab(3, "lol4");
 tcount=4;
 tupdate();
}
void generateTabsFromFile()
{
 if (readArgsFromFile())
 {
  tcount=1;
  tabargs = malloc(sizeof(struct tabData));
  makeTab(0, globalargs.tname);
  remove(".zb3dnd");
 }
 else generateSampleTabs();
}
void generatetabonXY(gint x, gint y)
{
 //set draggedpos, draggedtab
 tcount++;
 tabargs = realloc(tabargs, tcount*sizeof(struct tabData));
 gtk_widget_get_pointer(dframecopy, &x, &y);
 draggedpos = x / 80;
 if (draggedpos >= tcount)
 draggedpos = tcount-1;
 if (draggedpos < 0)
 draggedpos = 0;
 char i;
 for(i=(tcount-1); i>draggedpos; i--)
 {
  memcpy(tabargs+((i)), tabargs+((i-1)), sizeof(struct tabData));
 }
 makeTab(draggedpos, globalargs.tname);
 draggedtab = tabargs[draggedpos].twidget;
 tupdate();
}
void generatetab() //on draggedpos
{
 //set draggedpos, draggedtab
 tcount++;
 tabargs = realloc(tabargs, tcount*sizeof(struct tabData));
 if (draggedpos >= tcount)
 draggedpos = tcount-1;
 if (draggedpos < 0)
 draggedpos = 0;
 char i;
 for(i=(tcount-1); i>draggedpos; i--)
 {
  memcpy(tabargs+((i)), tabargs+((i-1)), sizeof(struct tabData));
 }
 makeTab(draggedpos, globalargs.tname);
 tupdate();
}
void whoops()
{
 gtk_widget_destroy(window);
}
void resetrecv(GtkWidget *widget, GdkDragContext *drag_context, guint time)
{
 gint x, y;
 gtk_widget_get_pointer(dframecopy, &x, &y);
 if ((x <= 0) || (y <= 0) || (x >= 300) || (y >= 100))
 {
  recv=0;
  isdown=2;
  setup_fake_request(drag_context, time); //ask source to set the icon
  removetab();
  if (tcount==0)
  {
   wait_and_die();
  }
 }
 else
 {
  recv=0;
  isdown=0;
  tupdate();
 }
}
void start_drag(GtkWidget *widget, guint32 time)
{
 isdown=2;
 generateglobalargs();
 if (sd != 1) removetab();
 globalcontext = gtk_drag_begin(widget, tl, GDK_ACTION_MOVE, 1, NULL);
 if (sd != 1) gtk_drag_set_icon_pixbuf(globalcontext, dragicon, globalargs.ptx, globalargs.pty);
 if (tcount==0)
 {
  wait_and_die();
 }
}
void preparedata(GtkWidget *widget, GdkDragContext *drag_context, GtkSelectionData *sdata, guint info, guint time, gpointer button)
{
 g_assert(sdata != NULL);
 if (is_fake_request())
 {
  gtk_drag_set_icon_pixbuf(globalcontext, dragicon, globalargs.ptx, globalargs.pty);
  destroy_fake_request();
 }
 else
 {
  gtk_drag_set_icon_default(drag_context);
 }
 gtk_selection_data_set(sdata, sdata->target, 8, (guchar*)&globalargs, sizeof(struct DATA));
}
void tswap(char pos1, char pos2)
{
 unsigned char *mybuff;
 mybuff = malloc(sizeof(struct tabData));
 memcpy(mybuff, tabargs+pos1, sizeof(struct tabData));
 memcpy(tabargs+pos1, tabargs+pos2,  sizeof(struct tabData));
 memcpy(tabargs+pos2, mybuff, sizeof(struct tabData));
 free(mybuff);
}
void getdatanow(GtkWidget *widget, GdkDragContext *context, gint x, gint y, guint t)
{
 if (recv==0)
 {
  recv=1;
  if (context->targets)
  {
   GdkAtom target_type;
   target_type = GDK_POINTER_TO_ATOM(g_list_nth_data(context->targets, 0));
   gtk_drag_get_data(widget, context, target_type, t);
  }
 }
 else if (recv==2 && draggedtab)
 {
  char asnow = x / 80;
  if (asnow >= tcount)
  asnow = tcount-1;
  if (asnow < 0)
  asnow = 0;
  if (asnow != draggedpos)
  {
   tswap(asnow, draggedpos);
   draggedpos = asnow;
   tupdate();
  }
  gtk_fixed_move(GTK_FIXED(fixed), draggedtab, x+30-ptx, 60);
 }
}
void onthebutton(GtkWidget *button, GdkEventButton *event)
{
 ptx = event->x; pty = event->y;
 gint t1, t2;
 gtk_widget_translate_coordinates(button, dframecopy, event->x, event->y, &t1, &t2);
 draggedpos = t1 / 80;
 if (draggedpos >= tcount)
 draggedpos = tcount-1;
 if (draggedpos < 0)
 draggedpos = 0;
  //gtk_fixed_remove(GTK_CONTAINER(fixed), button1);
  //gtk_fixed_put(GTK_FIXED(fixed), button1, 30+(draggedpos*80), 60);
 draggedtab = button;
 tabargs[draggedpos].twidget = button;
 gint x, y, x1, y1;
 gdk_window_get_origin(gtk_widget_get_window(draggedtab), &x, &y);
 gtk_widget_translate_coordinates(draggedtab, gtk_widget_get_toplevel(draggedtab), 0, 0, &x1, &y1);
 dragicon = gdk_pixbuf_get_from_drawable(NULL, gtk_widget_get_root_window(draggedtab), NULL, x+x1, y+y1, 0, 0, 75, 23);
 isdown=1;
}
void offthebutton() //only called on source when drag fails, if not, only dest will get this message... stupid GTK
{
 draggedtab = NULL;
 if (isdown==2)
 {
  gint mx, my;
  gdk_window_get_pointer(gtk_widget_get_root_window(dframecopy), &mx, &my, NULL);
  if(fork()==0)
  {
   char tx[32], ty[32];
   sprintf(tx, "%d", mx-35-ptx);
   sprintf(ty, "%d", my-85-pty);
   saveArgsToFile();
   execl("./gtktest", "70", tx, ty, 0);
   exit(0);
  }
  else
  {
   if (tcount==0)
   exit(0);
  }
 }
 else
 {
  ptx = 0; pty = 0;
  tupdate();
  remove(".zb3dnd2");
 }
 isdown=0;
}
void tabmotion(GtkWidget *widget, GdkEventMotion *event, gpointer dframe)
{
 if (isdown==1)
 {
  sd = 1;
  start_drag(GTK_WIDGET(dframe), event->time);
 }
}
void takedata(GtkWidget *widget, GdkDragContext *context, gint x, gint y, GtkSelectionData *selection_data, guint target_type, guint time, gpointer dframe)
{
 if((recv==1) && (selection_data != NULL) && (fakerequest!=1))
 {
  recv=2;
  struct DATA temp;
  memcpy(&globalargs, selection_data->data, sizeof(globalargs));
  isdown=1;
  ptx = globalargs.ptx;
  pty = globalargs.pty;
  if (sd==1)
  {
   sd = 0;
  }
  else 
  {
   generatetabonXY(x, y);
  }
 }
 if (fakerequest) 
 {
  fakerequest=0;
 }
}
int main(int argc, char **argv)
{
 gtk_init(&argc, &argv);
 window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
 gtk_window_set_default_size(GTK_WINDOW(window), 400, 150);
 gtk_window_set_title(GTK_WINDOW(window), "zb3 GTK app");
 if (argc==3)
 {
  gtk_window_move(GTK_WINDOW(window), atoi(argv[1]), atoi(argv[2]));
 }
 g_signal_connect(G_OBJECT(window),"destroy",G_CALLBACK(gtk_exit),NULL);
 
 tl = gtk_target_list_new(&target_list, 1);

 fixed = gtk_fixed_new();
 gtk_container_add(GTK_CONTAINER(window), fixed);
 
 GtkWidget *ebox;
 ebox = gtk_event_box_new();
 gtk_event_box_set_visible_window(GTK_EVENT_BOX(ebox), FALSE);
 GtkWidget *dragframe;
 dragframe = gtk_frame_new("loly");
 gtk_widget_set_size_request(dragframe, 320, 100);
 gtk_container_add(GTK_CONTAINER(ebox), dragframe);
 gtk_drag_dest_set(dragframe, GTK_DEST_DEFAULT_MOTION | GTK_DEST_DEFAULT_HIGHLIGHT, &target_list, 1, GDK_ACTION_MOVE);
 g_signal_connect(dragframe, "drag-leave", G_CALLBACK(resetrecv), NULL);
 g_signal_connect(dragframe, "drag-motion", G_CALLBACK(getdatanow), NULL);
 g_signal_connect(dragframe, "drag-data-received", G_CALLBACK(takedata), dragframe);
 g_signal_connect(dragframe, "drag-data-get", G_CALLBACK(preparedata), NULL);
 g_signal_connect(dragframe, "drag-drop", G_CALLBACK(offthebutton), NULL);
 g_signal_connect(dragframe, "drag-end", G_CALLBACK(offthebutton), NULL);
 gtk_fixed_put(GTK_FIXED(fixed), ebox, 30, 30);

 dframecopy = dragframe;
 if (argc==3)
 {
  generateTabsFromFile();
 }
 else
 {
  generateSampleTabs();
 }

 gtk_widget_show_all(window);
 
 gtk_main();
 free(tabargs);
 return 0;
}
