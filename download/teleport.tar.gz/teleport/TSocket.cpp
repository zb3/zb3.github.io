#include "main.hpp"
#include "TSocket.hpp"
#include "TEndian.hpp"

TSocket::TSocket() : csocket(-1)
{
 sockfd = socket(AF_INET, SOCK_STREAM, 0);
 if (sockfd==-1)
 {
  throw ERR_NO_SOCKET;
 }
}
TSocket::~TSocket()
{
 disconnect();
}
/*
should we expose individual shutdown?
I mean, if we write something before closing the socket, and call shut_rdwr
and close, will the other side be able to read what we've sent?
the only way to know is to test it

sth like ::signalTransferFailure?
but also ::sendTransferError
I mean, the sending side can send an IO error via code 0x03
there must be function for that
and receivefilechunk must throw exception based on that
*/
void TSocket::disconnect()
{
 shutdown(sockfd, SHUT_RDWR);
 close(sockfd);
 if (csocket!=-1)
 {
  shutdown(sockfd, SHUT_RDWR);
  close(csocket);
 }
}
int TSocket::readAll(int c, char *buf, int count)
{
 int wtemp = 0, terror;
 while((terror=read(c, buf+wtemp, count-wtemp))>0 && wtemp<count)
 wtemp+=terror;
 if (terror<0 || wtemp<count)
 return ERR_READ;
 return 0;
}
int TSocket::writeAll(int c, char *buf, int count)
{
 int wtemp = 0, terror;
 while((terror=write(c, buf+wtemp, count-wtemp))>0 && wtemp<count)
 wtemp+=terror;
 if (terror<0 || wtemp<count)
 return ERR_READ;
 return 0;
}
void TSocket::initClient(char *ip, int portnum)
{
 struct sockaddr_in cto;
 memset(&cto, 0, sizeof(cto));
 cto.sin_family = AF_INET;
 cto.sin_addr.s_addr = inet_addr(ip);
 cto.sin_port = htons(portnum);
 terror = connect(sockfd, (struct sockaddr *)&cto, sizeof(struct sockaddr));
 if (terror)
 throw ERR_CONNECT;
 csocket = sockfd;
}
void TSocket::initServer(int portnum)
{
 struct sockaddr_in serv;

 memset(&serv, 0, sizeof(serv)); 
 serv.sin_family = AF_INET;
 serv.sin_addr.s_addr = htonl(INADDR_ANY);
 serv.sin_port = htons(portnum);
 
 if (terror = bind(sockfd, (struct sockaddr *)&serv, sizeof(struct sockaddr)))
 throw errno==EACCES?ERR_BIND_ACCESS:errno==EADDRINUSE?ERR_BIND_USE:ERR_BIND;

 if (terror = listen(sockfd, 5))
 throw ERR_LISTEN; 
}

void TSocket::acceptClient(char *ip)
{
 struct sockaddr_in dest;
 socklen_t socksize = sizeof(struct sockaddr_in);

 while((csocket = accept(sockfd, (struct sockaddr *)&dest, &socksize)) > 0)
 {
  if (strcmp(inet_ntoa(dest.sin_addr), ip)) continue;
  return;
 }
 throw ERR_ACCEPT;
}
void TSocket::sendMode(char mode, char *mode2)
{
 if (write(csocket, &mode, 1)!=1)
 throw ERR_WMODE;

 if (read(csocket, mode2, 1)!=1)
 throw ERR_WMODE;
}
void TSocket::recvMode(char mode, char *mode2)
{
 if (read(csocket, mode2, 1)!=1)
 throw ERR_RMODE;

 if (write(csocket, &mode, 1)!=1)
 throw ERR_RMODE;
}
void TSocket::sendName(char *name, uint64_t mfsize, uint64_t *seekpos)
{
 strcpy(buff, name);
 if (terror=writeAll(csocket, buff, BUFSIZE))
 throw ERR_SN;

 uint64_t nmfsize = htobe64(mfsize);
 uint64_t nseekpos;

 if (terror=writeAll(csocket, (char*)(&nmfsize), 8))
 throw ERR_SN;
 if (terror=readAll(csocket, (char*)(&nseekpos), 8))
 throw ERR_SN;

 *seekpos = be64toh(nseekpos);
}
void TSocket::waitForFname(char *fname, uint64_t *mfsize)
{
 if (terror=readAll(csocket, fname, BUFSIZE))
 throw ERR_SN;
 
 uint64_t nmfsize;

 if (terror=readAll(csocket, (char*)&nmfsize, 8))
 throw ERR_SN;

 *mfsize = be64toh(nmfsize);
}
void TSocket::sendRemaining(uint64_t mfsize)
{
 uint64_t nmfsize = htobe64(mfsize);

 if (terror=writeAll(csocket, (char*)&nmfsize, 8))
 throw ERR_WN;
}
void TSocket::sendFileChunk(char *buf, int bsize)
{
 //now look, I'll try to send stuff
 //but if the previous sFC failed on their side
 //they disconnected, but before that they'd sent 
 //a packet informing why
 //so if an error occurs, call receiveTransferError (private)
 //and THAT function will throw the proper exception
 char x = 0x00;
 if (bsize==BUFSIZE)
 {
  if (write(csocket, &x, 1)!=1)
  throw ERR_WRITE;
 }
 else if (!bsize) //means: transfer complete (yes, if we fail to read before we read the full file, we'll send an error message)
 {
  x = 0x02;
  if (write(csocket, &x, 1)!=1)
  throw ERR_WRITE;
 }
 else
 {
  x = 0x01;
  if (write(csocket, &x, 1)!=1)
  throw ERR_WRITE;

  uint32_t nbsize = htons(bsize);

  if (terror=writeAll(csocket, (char*)&nbsize, 4))
  throw ERR_WRITE;
 }
 if (terror=writeAll(csocket, buf, bsize))
 throw ERR_WRITE;
}
int TSocket::getFileChunk(char *buf)
{
 char mode; uint32_t toread = BUFSIZE;
 if (read(csocket, &mode, 1)!=1)
 throw ERR_READ;
 if (mode==0x02)
 return 0; //yay, transfer complete. but hey, this is useless as we know the file size, right?
 else if (mode==0x01)
 {
  if (terror=readAll(csocket, (char *)&toread, 4))
  throw ERR_READ;

  toread = ntohs(toread);
 }
 else if (mode!=0x00)
 throw mode;

 if (terror=readAll(csocket, buf, toread))
 throw ERR_READ;

 return toread;
}