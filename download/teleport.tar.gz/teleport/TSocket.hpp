#ifndef TSocket_h
#define TSocket_h

#include <stdio.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <cerrno>

/*
the problem is that there are dozens of underlying uint64 to int conversions...
*/
class TSocket
{
 int sockfd; int terror; int mode; int csocket;
 uint64_t wtemp;
 char buff[BUFSIZE]; char buff2[BUFSIZE];
 int readAll(int c, char *buf, int count);
 int writeAll(int c, char *buf, int count);
 void receiveTransferError();
 public:
 TSocket();
 ~TSocket();
 void disconnect();
 void initClient(char *ip, int port);
 void initServer(int port);
 void acceptClient(char *ip);
 void sendMode(char mode, char *mode2);
 void recvMode(char mode, char *mode2);
 void sendName(char *name, uint64_t mfsize, uint64_t *seekpos);
 void waitForFname(char *fname, uint64_t *mfsize);
 void sendRemaining(uint64_t mfsize);
 void sendTransferError(errors code, bool receiver); //for sender
 void sendFileChunk(char *buf, int bsize);
 int getFileChunk(char *buf); //not void

};
#endif //TSocket_h
/*
we need to rethink the communication process.
so that there will be error codes.
the main problem is how to implement control packets
so that it doesn't slow the process down

also, how do we handle these messages?

looks like there is no answer to our problem, we need to try to solve it on our own

but this wasn't meant to be multithreaded...
[threading can get complicated! reason: windows]
what about:
we'll be sending it and if we encounter a write error, then we'll stop, and try
to receive the error message

(sendFileChunk will return an error)

ok, so since we've agreed to avoid multithreading ... :)
we can use shared buffers & stuff because we know that is synchronized

EHKM.... how does it relate to exceptions?
need to USE them, more pro... :>

well, exceptions need to be used for constructors, that's for sure
in c++ that's better than in Java, we can use ints !!!
just throw ERROR_CODE; and we're done
literally, we don't even need any specification, just throw
BUT.. do it like:
TSocket tsocket;
try
{
 tsocket = new TSocket();
}
catch(int err)
{
 //blah blah blah unable to create socket
 //return;
}

EDIT: google style guide prohibits exceptions O_O
maybe we shouldn't be using them?
EDIT2: maybe we shouldn't be following google style guide :> ?
PS. use enum for error codes

once again, what about displaying errors?
should the class do it?
no, the class should only return the corresponding error value

but it's not possible for initServer.
it should return OUR error code, which means we translate
the error codes of standard functions.
the best solution would be to make a struct
struct TError
{
 errors o;
 int t;
}
but since we're not actually going anywhere, maybe just skip
this totally unimportant stuff

EDIT: note about error handling
maybe we should use exceptions, so that the code
is shorter, just wrap around try and make ONE
catch block instead of repeated stuff

and a nested one, because if we start sending/receiving
then we want to display what has been done so far

maybe also sendall?
*/
/*
we need to rethink it all, because currently we fail.
first of all, we must not use stuff like size_t, off_t etc.
that's because we'll send it over network, so types must be 
platform-independent. so, we have to use the biggest possible type
that's probably unsigned long long
so it's => uint64_t

there's no bigger type, that should be ok.
well.. what about endianess

ok, ok. I know a bit about that now.
It's called network byte order, which is nothing but just big endian.
unfortunately, there's no htonll, so we will have to write
portable function that will act as it.

maybe in header named endian.h
this function will be named htobe64.

good. now we need to properly cast all returns from file functions
to our uint64_t. properly...

it also looks like because unsigned of the same or bigger size wins, that
all the results will be converted to uint64_+t
*/