#define _FILE_OFFSET_BITS 64
#define LINUX TRUE
#include <iostream>
#include <stdio.h>
#include "main.hpp"
#include "TSocket.hpp"

using namespace std;

const char *err_str(errors code)
{
 switch(code)
 {
  case ERR_CONNECT:
  return "Connect failed.";
  case ERR_BOTH_SEND:
  return "Conflicting modes! (no reciever)";
  case ERR_BOTH_RECV:
  return "Conflicting modes! (no sender)";
  case ERR_BIND:
  return "Bind failed.";
  case ERR_BIND_ACCESS:
  return "Bind failed. (permission denied)";
  case ERR_BIND_USE:
  return "Bind failed. (address in use)";
  case ERR_LISTEN:
  return "Listen failed.";
  case ERR_ACCEPT:
  return "Accept failed.";
  case ERR_WMODE:
  case ERR_RMODE:
  return "Error exchanging modes.";
  case ERR_ALREADY_THERE:
  return "The file has already been sent.";
  case ERR_WN:
  case ERR_SN:
  return "Error exchanging file info.";
  case ERR_READ:
  return "Read error.";
  case ERR_WRITE:
  return "Write error.";
  case ERR_FILE_WRITE:
  return "Cannot write to file.";
 }
}

float sizePercent(uint64_t n, uint64_t d)
{
 if (n==d)
 {
  return 100;
 }
 else if (d<1000)
 {
  return 100*(float)n/(float)d;
 }
 else
 {
  return (n/(d/1000ULL))/10.0;
 }
}


int main(int argc, char **argv)
{
 /*
 arguments:
 teleportfile [mode] [ip] [file] 

 */
 int terror = 0;
 if (argc<2)
 {
  fprintf(stderr, "Usage:\n");
  fprintf(stderr, "%s [mode [client/server]] [IP] [port] [file]\n", argv[0]);
  fprintf(stderr, "For server receive mode, IP is the address that will be allowed to send a file.\n");
  return -1;
 }
 bool sender = argc==5; uint64_t mfsize;
 FILE *ourfile = NULL;
 if (sender)
 {
  ourfile = fopen(argv[4], "rb");
  if (!ourfile)
  {
   fprintf(stderr, "Failed to open file for reading!\n");
   return -1;
  }
#ifdef LINUX
  struct stat buf;
  terror = stat(argv[4], &buf);
#else
  struct _stat buf;
  terror = _stat(argv[4], &buf);
#endif
  if (terror)
  {
   if (ourfile)
   fclose(ourfile);
   fprintf(stderr, "Failed to open file for reading!\n");
   return -1;
  }

  mfsize = buf.st_size;
 }

 try
 {
  TSocket ts;
  bool client = !strcmp(argv[1], "client");
  if (client)
  {
   ts.initClient(argv[2], atoi(argv[3]));
   fprintf(stdout, "Connected to %s on port %d\n", argv[2], atoi(argv[3]));
  }
  else
  {
   ts.initServer(atoi(argv[3]));
   fprintf(stdout, "Listening for %s on port %d\n", argv[2], atoi(argv[3]));
   ts.acceptClient(argv[2]);
   fprintf(stdout, "%s Connected\n", argv[2]);
  }
  char buff[BUFSIZE]; uint64_t sent, received, seekpos, twrite, twrite2; int tsize;

  char ourmode = sender?1:0, theirmode;
  if (client)
  ts.sendMode(ourmode, &theirmode);
  else
  ts.recvMode(ourmode, &theirmode);

  if (ourmode==theirmode)
  throw ourmode?ERR_BOTH_SEND:ERR_BOTH_RECV;

  if (sender)
  {
   ts.sendName(argv[4], mfsize, &seekpos);

   if (seekpos>=mfsize)
   throw ERR_ALREADY_THERE; 

   fseek(ourfile, seekpos, SEEK_SET); 

   sent = seekpos;
   fprintf(stdout, "Sending file %s, %.1f%s complete (sent %llu bytes so far)", argv[4], sizePercent(sent, mfsize), "%", sent);

   try
   {
    while((tsize=fread(buff, 1, BUFSIZE, ourfile))>0)
    {
     ts.sendFileChunk(buff, tsize);
     sent+=tsize;
     fprintf(stdout, "\rSending file %s, %.1f%s complete (sent %llu bytes)", argv[4], sizePercent(sent, mfsize), "%", sent);
    }
    if (sent<mfsize)
    throw ERR_READ;
    ts.sendFileChunk(buff, 0);
    fprintf(stdout, "\nFile transfer complete!\n");
   }
   catch(errors e)
   {
    fprintf(stdout, "\nFile transfer error: %s", err_str(e));
    fprintf(stdout, "\nSent %llu bytes so far (%.1f%s complete)", sent, sizePercent(sent, mfsize), "%");
   }
  }
  else
  {
   //receive mode, actually harder to implement
   char fname[4096];
   ts.waitForFname(fname, &mfsize);
   fprintf(stdout, "Size there is %llu\n", mfsize);
   ourfile = fopen(fname, "ab");
   if (!ourfile)
   throw ERR_FILE_WRITE;
   seekpos = ftell(ourfile);
   ts.sendRemaining(seekpos);
   if (seekpos>=mfsize)
   throw ERR_ALREADY_THERE; 
 
   received = seekpos;
   fprintf(stdout, "Receiving file %s, %.1f%s complete (received %llu bytes so far)", fname, sizePercent(received, mfsize), "%", received);
   try
   {
    while((tsize=ts.getFileChunk(buff))>0)
    {
     if (fwrite(buff, 1, tsize, ourfile)!=tsize)
     throw ERR_FILE_WRITE;
     received += tsize;
     fprintf(stdout, "\rReceiving file %s, %.1f%s complete (received %llu bytes so far)", fname, sizePercent(received, mfsize), "%", received);
    }
    if (received<mfsize)
    throw ERR_READ;
    fprintf(stdout, "\nFile transfer complete!\n");
   }
   catch(errors e)
   {
    fprintf(stdout, "\nFile transfer error: %s", err_str(e));
    fprintf(stdout, "\nReceived %llu bytes so far (%.1f%s complete)", received, sizePercent(received, mfsize), "%");
   }
  }
 }
 catch(errors e)
 {
  fprintf(stdout, "\nError occured: %s\n", err_str(e));
 }
 if (ourfile)
 fclose(ourfile);
 return -1;
}
