#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <fcntl.h>
#include <errno.h>

#define BUFSIZE 2048

unsigned int usecs = 5000;
struct winsize w, wo;

typedef struct
{
 unsigned char e;
 int x;
 int y;
} ttysize;

int servfd, sockfd, ok=1;

void *readproc()
{
 char readbuf[BUFSIZE]; int bytes=1;
 while(bytes!=0)
 {
  bytes = read(sockfd, readbuf, BUFSIZE);
  if (bytes > 0) {write(1, readbuf, bytes);}
  else if ((errno == EWOULDBLOCK) || (errno == EAGAIN)) usleep(usecs);
  else {ok=0;}
 }
}

void *writeproc()
{
 char readbuf[BUFSIZE]; int bytes; ttysize ts; ts.e=0xf7;
 while(ok)
 {
  ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
  if (memcmp(&w, &wo, sizeof(struct winsize)))
  {
   ts.x=w.ws_col;ts.y=w.ws_row;
   write(sockfd, &ts, sizeof(ts));
   wo=w;
  }
  bytes = read(0, readbuf, BUFSIZE);
  write(sockfd, readbuf, bytes);
  usleep(usecs);
 }
}

int main(int argc, char **argv)
{
 int port;
 if (argc<2 || ((port = atoi(argv[1]))<0) || port>65535)
 {
  fprintf(stderr, "%s [port]\n", argv[0]);
  return 0;
 }

 servfd = socket(AF_INET6, SOCK_STREAM, 0);
 struct sockaddr_in6 addr;
 addr.sin6_family = AF_INET6;
 addr.sin6_addr = in6addr_any;
 addr.sin6_port = htons(port);

 if (bind(servfd, (struct sockaddr *)&addr, sizeof(addr)))
 {
  perror("Failed to bind");
  return -1;
 }
 if (port==0) //tell which port we are listening on
 {
  int len; len=sizeof(addr);
  getsockname(servfd, (struct sockaddr *)&addr, &len);
  fprintf(stdout, "Listening on port %d\n", ntohs(addr.sin6_port));
  fflush(stdout);
 }
 listen(servfd, 1);

 sockfd = accept(servfd, (struct sockaddr*)NULL, NULL);
 
 ttysize ts;
 ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
 wo=w;
 ts.e = 0xf7;
 ts.x=w.ws_col; ts.y=w.ws_row;

 write(sockfd, &ts, sizeof(ts));
 char term[1025]={0};

 strcat(term, getenv("TERM")); 

 write(sockfd, term, 1025);

 struct termios tn, to;

 tcgetattr(0, &to);
 tn=to;

 tn.c_iflag&=~ICRNL;
 tn.c_lflag&=~ICANON;
 tn.c_lflag&=~ECHO;
 tn.c_cc[VMIN ]=1;
 tn.c_cc[VTIME]=0;
 tn.c_cc[VINTR]=0xFF;
 tn.c_cc[VSUSP]=0xFF;
 tn.c_cc[VQUIT]=0xFF;

 tcsetattr(0, TCSANOW, &tn);

 int flags = fcntl(sockfd, F_GETFL, 0);
 fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);

 flags = fcntl(0, F_GETFL, 0);
 fcntl(0, F_SETFL, flags | O_NONBLOCK);

 pthread_t reader, writer;
 
 pthread_create(&reader, NULL, readproc, NULL);
 pthread_create(&writer, NULL, writeproc, NULL);

 pthread_join(reader, NULL);
 pthread_join(writer, NULL);
  
 tcsetattr(0, TCSANOW, &to);
 close(sockfd); close(servfd);

 return 0;
}