gcc superwave.c -o superwave -lpthread
