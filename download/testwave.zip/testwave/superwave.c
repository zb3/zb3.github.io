#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <pthread.h>
#include <termios.h>
#include <errno.h>

unsigned char running=1;
//begin terminal stuff
void term_fail()
{
 fprintf(stderr, "unable to set terminal characteristics\n");
 perror("");                                                
 exit(1);                                                   
}

int checktty(struct termios *p, int term_fd)
{
 struct termios ck;
 return (tcgetattr(term_fd, &ck) == 0 && (p->c_lflag == ck.c_lflag) && (p->c_cc[VMIN] == ck.c_cc[VMIN]) && (p->c_cc[VTIME] == ck.c_cc[VMIN]));
}
int keypress(int term_fd)
{
 unsigned char ch;
 int retval=read(term_fd, &ch, sizeof ch);
 //optional checking here
 return retval;
}
int flush_term(int term_fd, struct termios *p)
{
 struct termios newterm;
 errno=0;
 tcgetattr(term_fd, p);  /* get current stty settings*/
 newterm = *p;  newterm.c_lflag &= ~(ECHO | ICANON); 
 newterm.c_cc[VMIN] = 0;  newterm.c_cc[VTIME] = 0; 
 return(tcgetattr(term_fd, p) == 0 && tcsetattr(term_fd, TCSAFLUSH, &newterm) == 0 && checktty(&newterm, term_fd) != 0);
}
void wfc(void)
{
 struct timespec tsp={0,500};  /* sleep 500 usec (or likely more ) */
 struct termios  attr;
 struct termios *p=&attr;
 int term_fd=fileno(stdin);
 fflush(stdout);
 if(!flush_term(term_fd, p))
 term_fail();
 while (running==1)
 {
  nanosleep(&tsp, NULL);
  switch(keypress(term_fd))
  {
   case 0:
   default:
   break;
   case -1:
   fprintf(stdout, "Read error %s", strerror(errno));
   exit(1);
   break;
   case 1:
   running=3;
   break;                 
  } 
 }
 if(tcsetattr(term_fd, TCSADRAIN, p) == -1 && tcsetattr(term_fd, TCSADRAIN, p) == -1)
 term_fail();
}
//end terminal stuff
unsigned short *wave;
unsigned short length;
unsigned short max;
char rootdir=1;

struct winsize w;

void update_size()
{
 ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
 length = w.ws_col-2;
 if (w.ws_row-1 > max)
 {
  max = w.ws_row;
  wave = realloc(wave, max*sizeof(unsigned short));
 }
 else
 {
  max = w.ws_row;
 }
}

void next_wave(char fill)
{
 unsigned short last=0, row=0;
 char dir=rootdir;
 if (fill)
 last = 0;
 else
 last = wave[0];
 while (row<max)
 {
  if ((last+dir)>length) 
  {
   dir = -dir;
   last = length;
  }
  else if ((last+dir)<=0)
  {
   dir = -dir;
  }
  if (!row) rootdir = dir;
  last += dir;
  wave[row] = last;
  row++;
 }
}

void print_wave()
{
 unsigned short t=0, f=0;
 for(;t<max;t++,f=0)
 {
  fprintf(stdout, "[");
  for(;f<t[wave];f++)
  fprintf(stdout, "#");
  for(;f<length;f++)
  fprintf(stdout, " ");
  if (t<(max-1))
  fprintf(stdout, "]\n");
 }
 fflush(stdout);
}

void erase_wave()
{
 fprintf(stdout, "\033[%dA\033[K\r", max);
 fflush(stdout);
}

void *paint_wave()
{
 struct timespec tsp={0,81212600}; 
 update_size();
 next_wave(1);
 print_wave();
 while (running==1)
 {
  nanosleep(&tsp, NULL);
  erase_wave();
  update_size();
  next_wave(0);
  print_wave();
 }
 running=10;
 return NULL;
}
int main()
{
 wave = malloc(1);
 pthread_t worker;
 pthread_create(&worker, NULL, paint_wave, (void *)NULL);
 wfc();
 struct timespec tsp={0,500};
 while (running!=10) //now wait for our thread to finish LOL
 {
  nanosleep(&tsp, NULL);
 }
 free(wave);
}
